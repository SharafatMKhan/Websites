<!DOCTYPE html>
<html lang="en">


<head>
     <title>Presently Solutions | Software Development Company</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
        content="We are US based  software company in India that offers abundant software services and  solutions to minimise work and maximise the success of your business."
        property="description">
    <meta name="author" content="Presently Solutions" property="author">
    <meta name="canonical" content="https://presently.in/domain-&-hosting.php" property="canonical">
    <meta name="robots" content="Index, follow">
    <meta name="og:title" content="Presently Solutions:Top IT Company " property="og:title">
    <meta name="og:description" content="Presently Solutions software development company in Bhopal,India"
        property="og:description">
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <meta name="keywords" content="Leading It company in Bhopal,Customized software service,Web design and development,
         mobile app development, Software solutions,app developers, web application and development, leading software solution provider in Bhopal,India,Dynamic Websites,Bhopal web development, Bhopal mobile app development, Bhopal app developer, Bhopal web design, Bhopal logo design,
         US based IT company in Thrissur,Custom developed websites,WebSite Hosting,software support and solutions in Bhopal,India,
         Professionals in software development, Best software company in Central India " property="keywords">
    <meta name="keyphrase"
        content="Best Software company in thrissur, Top IT company in Bhopal,software solutions,
                Website design and development company Bhopal,IOS and Andoird application development company Thrissur" />
    <meta name="topic" content="Software" />
    <meta name="subject" content="Software" />
    <meta name="classification" content="Software,Website development,Leading,Best,Top Company" />
    <meta name="rating" content="general">
    <meta name="audience" content="all" />
    <meta property="og:type" content="Software Company" />
    <meta property="og:url" content="https://www.facebook.com/presentlysolutions/" />
    <meta property="og:site_name" content="www.Presently.in" />
    <meta name="og:image" content="img/companyculture.png" />
    <meta name="og:email" content=" info@presently.in" />
    <meta name="og:phone_number" content="+919993357325" />
    <meta itemprop="name" content="Software Company, Bhopal" />
    <meta itemprop="description"
        content="Presently Soultions is the top web designing and web development in Bhopal who offers attractive website designs with creative web designers in Bhopal" />
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <link rel="canonical" href="index.php" />
    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700"
        rel="stylesheet">
    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">

    <script src='../www.google.com/recaptcha/api.js'></script>

</head>

<body>
    <!--==========================
  Header
  ============================-->
<?php include("part/header.php"); ?>
<!-- #header -->
	

    <main id="main">
	
	 <section  class="inner-banner text-center" style="background-image:url('img/hosting.jpg')">
            <div class="container">
                <div class="box">
                    <h3>
                     DOMAIN & HOSTING</h3>
                </div>
            </div>
</section>

        <!--==========================
      About Us Section
    ============================-->
        <section id="about">

            <div class="container">
                <div class="row"> 

                    <div class="col-lg-12 col-md-12">
                        <div class="about-content">
                            <h2>DOMAIN NAME REGISTRATION</h2>
                            <p style="line-height: 2;">DOMAIN NAME REGISTRATION
When planning to get a website created, the first question that comes to mind is “What is a Domain?” The internet is the perfect place to jump start your business. You will be able to reach customers around the world. Domain names will help you do this. Let us be your guide in securing a cheap domain. You will be able to get priceless exposure to the world market, by spending just a little amount each year. Increase the success of your business with domain names, as your website URL will be advertisement in itself.</p>
<h2>WEB HOSTING</h2>
                            <p style="line-height: 2;">Are you looking for a dependable web hosting space to launch your website? You have come to the right place. We are a providing web hosting spaces in all over world. Canrone provides complete web hosting solutions for both, individuals who desire full functionality on a small budget, and small-to medium-sized businesses. We offer high quality, affordable and security-oriented web hosting services along with speed, reliability and flawless customer service.</p><a href=""></a>

                        </div>
                        </div>
                        </div>
						
					
					
              
            </div>

        </section><!-- #about -->

 
  </main>
    <!--==========================
    Footer
  ============================-->
  <?php include("part/footer.php"); ?>
  <!-- #footer -->

   

</body>


</html>