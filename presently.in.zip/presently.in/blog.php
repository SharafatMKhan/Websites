<!DOCTYPE html>
<html lang="en">


<head>
    <title>Portfolio | Presently Solutions | Software Development Company</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="We are US based  software company in India that offers abundant software services and  solutions to minimise work and maximise the success of your business." property="description">
    <meta name="author" content="Presently Solutions" property="author">
    <meta name="canonical" content="https://presently.in/portfolio.php" property="canonical">
    <meta name="robots" content="Index, follow">
    <meta name="og:title" content="Presently Solutions:Top IT Company " property="og:title">
    <meta name="og:description" content="Presently Solutions software development company in Bhopal,India" property="og:description">
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <meta name="keywords" content="Leading It company in Bhopal,Customized software service,Web design and development,
         mobile app development, Software solutions,app developers, web application and development, leading software solution provider in Bhopal,India,Dynamic Websites,Bhopal web development, Bhopal mobile app development, Bhopal app developer, Bhopal web design, Bhopal logo design,
         US based IT company in Thrissur,Custom developed websites,WebSite Hosting,software support and solutions in Bhopal,India,
         Professionals in software development, Best software company in Central India " property="keywords">
    <meta name="keyphrase" content="Best Software company in thrissur, Top IT company in Bhopal,software solutions,
                Website design and development company Bhopal,IOS and Andoird application development company Thrissur" />
    <meta name="topic" content="Software" />
    <meta name="subject" content="Portfolio" />
    <meta name="classification" content="Software,Website development,Leading,Best,Top Company" />
    <meta name="rating" content="general">
    <meta name="audience" content="all" />
    <meta property="og:type" content="Software Company" />
    <meta property="og:url" content="https://www.facebook.com/presentlysolutions/" />
    <meta property="og:site_name" content="www.Presently.in" />
    <meta name="og:image" content="img/companyculture.png" />
    <meta name="og:email" content=" info@presently.in" />
    <meta name="og:phone_number" content="+919993357325" />
    <meta itemprop="name" content="Software Company, Bhopal" />
    <meta itemprop="description" content="Presently Soultions is the top web designing and web development in Bhopal who offers attractive website designs with creative web designers in Bhopal" />
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <link rel="canonical" href="index.php" />
    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700" rel="stylesheet">
    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.0-beta2/css/bootstrap.min.css' integrity='sha512-aqT9YD5gLuLBr6ipQAS+72o5yHKzgZbGxEh6iY8lW/r6gG14e2kBTAJb8XrxzZrMOgSmDqtLaF76T0Z6YY2IHg==' crossorigin='anonymous' />
    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">
    <!-- Team CSS Link-->
    <link rel="stylesheet" href="./css/team.css">
    <!-- Team CSS Link-->

    <style>
        /* Popup container - can be anything you want */
        .popup {
            position: relative;
            display: inline-block;
            cursor: pointer;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        /* The actual popup */
        .popup .popuptext {
            visibility: hidden;
            width: 300px;
            background-color: #555;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 8px 0;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            left: 50%;
            margin-left: -80px;
        }

        /* Popup arrow */
        .popup .popuptext::after {
            content: "";
            position: absolute;
            top: 100%;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: #555 transparent transparent transparent;
        }

        /* Toggle this class - hide and show the popup */
        .popup .show {
            visibility: visible;
            -webkit-animation: fadeIn 1s;
            animation: fadeIn 1s;
        }

        /* Add animation (fade in the popup) */
        @-webkit-keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }
    </style>
</head>

<body>
    <!--==========================
  Header
  ============================-->
    <?php include("part/header.php"); ?>
    <!-- #header -->


    <main id="main">

        <!-- <section  class="inner-banner text-center" style="background-image:url('img/portfoliobanner.png')"> -->
        <section class="inner-banner text-center" style="background-image:url('img/portfolio/team1.jpg')">
            <div class="container">
                <div class="box">
                    <h3>
                        Blogs</h3>
                </div>
            </div>
        </section>

        <!-- Our Team Section -->
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <!------ Include the above in your HEAD tag ---------->

        <!-- Team -->
        <div class="container">
    <div class="row">
        <div class="col-md-10 mt-5">
            <h3>Heading 1</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla ratione voluptates adipisci, minus rem commodi odio optio sed debitis quibusdam.
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur, reiciendis!
            </p>
        </div>
        <div class="col-md-2" >
            <img src="./img/hrm.jpg" alt="" style="height:200px;width: 240px" class="mt-5">
        </div>
        <hr>
        <div class="col-md-10">
            <h3>Heading 2</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla ratione voluptates adipisci, minus rem commodi odio optio sed debitis quibusdam.</p>
        </div>
        <div class="col-md-2" >
            <img src="./img/hrm.jpg" alt="" style="height:200px;width: 240px" class="mt-5">
        </div>
        <hr>

        <div class="col-md-10">
            <h3>Heading 3</h3>
            <p>Lorem ipsu dolor sit amet, consectetur adipisicing elit. Nulla ratione voluptates adipisci, minus rem commodi odio optio sed debitis quibusdam.</p>
        </div>
        <div class="col-md-2" >
            <img src="./img/hrm.jpg" alt="" style="height:200px;width: 240px" class="mt-5">
        </div>
        <hr>

        <div class="col-md-10">
            <h3>Heading 4</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla ratione voluptates adipisci, minus rem commodi odio optio sed debitis quibusdam.</p>
        </div>
        <div class="col-md-2" >
            <img src="./img/hrm.jpg" alt="" style="height:200px;width: 240px" class="mt-5">
        </div>

        <hr>

        <div class="col-md-10">
            <h3>Heading 5</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla ratione voluptates adipisci, minus rem commodi odio optio sed debitis quibusdam.</p>
        </div>
        <div class="col-md-2" >
            <img src="./img/hrm.jpg" alt="" style="height:200px;width: 240px" class="mt-5">
        </div>
    </div>
</div>

    <!--==========================
    Footer
  ============================-->
    <?php include("part/footer_team.php"); ?>
    <!-- #footer -->



</body>


</html>