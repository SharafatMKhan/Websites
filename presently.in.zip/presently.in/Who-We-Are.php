<!DOCTYPE html>
<html lang="en">


<head>
         <title>Who We Are | Presently Solutions | Software Development Company</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
        content="At Presently, we make BRANDS AND BUSINESSES achieve exponential success by effectively leveraging the combined power of Mobile, Social Media, Web, Videos and Data Analytics to excite and engage consumers."
        property="description">
    <meta name="author" content="Presently Solutions" property="author">
    <meta name="canonical" content="https://presently.in/Who-We-Are.php" property="canonical">
    <meta name="robots" content="Index, follow">
    <meta name="og:title" content="Presently Solutions:Top IT Company " property="og:title">
    <meta name="og:description" content="Presently Solutions software development company in Bhopal,India"
        property="og:description">
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <meta name="keywords" content="Leading It company in Bhopal,Customized software service,Web design and development,
         mobile app development, Software solutions,app developers, web application and development, leading software solution provider in Bhopal,India,Dynamic Websites,Bhopal web development, Bhopal mobile app development, Bhopal app developer, Bhopal web design, Bhopal logo design,
         US based IT company in Thrissur,Custom developed websites,WebSite Hosting,software support and solutions in Bhopal,India,
         Professionals in software development, Best software company in Central India " property="keywords">
    <meta name="keyphrase"
        content="Best Software company in thrissur, Top IT company in Bhopal,software solutions,
                Website design and development company Bhopal,IOS and Andoird application development company Thrissur" />
    <meta name="topic" content="Software" />
    <meta name="subject" content="Who We Are" />
    <meta name="classification" content="Software,Website development,Leading,Best,Top Company" />
    <meta name="rating" content="general">
    <meta name="audience" content="all" />
    <meta property="og:type" content="Software Company" />
    <meta property="og:url" content="https://www.facebook.com/presentlysolutions/" />
    <meta property="og:site_name" content="www.Presently.in" />
    <meta name="og:image" content="img/companyculture.png" />
    <meta name="og:email" content=" info@presently.in" />
    <meta name="og:phone_number" content="+919993357325" />
    <meta itemprop="name" content="Software Company, Bhopal" />
    <meta itemprop="description"
        content="Presently Soultions is the top web designing and web development in Bhopal who offers attractive website designs with creative web designers in Bhopal" />
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <link rel="canonical" href="index.php" />
    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700"
        rel="stylesheet">
    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">


	
</head>

<body>
    <!--==========================
  Header
  ============================-->
<?php include("part/header.php"); ?>
<!-- #header -->
	

    <main id="main">

	 <section  class="inner-banner text-center" style="background-image:url('img/servicessolutions.jpg')" >
            <div class="container">
                <div class="box">
                    <h3>
                     Who We Are</h3>
                </div>
            </div>
</section>

        <!--==========================
      About Us Section
    ============================-->
        <section id="about">

            <div class="container">
                <div class="row">

                    <div class="col-lg-5 col-md-6">
                        <div class="about-img">
                            <img src="img/companyculture.png" alt="">
                        </div>
                    </div>

                    <div class="col-lg-7 col-md-6">
                        <div class="about-content">
                            <h2>About Us</h2>
                            <p style="line-height: 2;">At Presently, we make BRANDS AND BUSINESSES achieve exponential success by effectively leveraging the combined power of Mobile, Social Media, Web, Videos and Data Analytics to excite and engage consumers. A Bunch of Qualified Professionals across various territories joined hands together with an ultimate aim to provide you technological comfort and easy handling, upholding both the moral and ethical values.</p>
                        </div>
                    </div>
					
					 <div class="col-lg-7 col-md-6">
                        <div class="about-content">
                          
                            <p style="line-height: 2;">Founded in 2018 in Bhopal, India, Presently It started as a web
                                development
                                company and quickly moved into the mobile development market. Today we are a full-cycle
                                service provider
                                with a dedicated development team with expertise in web & mobile development, project
                                management,
                                digital design, technical support and quality assurance. Our sales, marketing and
                                business management
                                team is spread out throughout the united states. Collaboratively, we are passionate
                                about delivering
                                finished products that exceed our customer expectations. We are continuously evolving
                                and entering new
                                markets with hopes to stay ahead in the disruptive technology space!</p>
                        </div>
                    </div>
					
					<div class="col-lg-5 col-md-6">
                        <div class="about-img">
                            <img src="img/companyculture.png" alt="">
                        </div>
                    </div>
					
					 <div class="col-lg-6 col-md-6">
                        <div class="about-content">
                           <h2>Vision</h2>
                            <p style="line-height: 2;">Presently vision is to be a predominant specialist co-op of proficient and financially savvy IT arrangement. Promise to the given errand, add up to client care, dynamic business collaboration, selection of lively innovation and keeping up administration position are our controlling standards and quality.</p>
                        </div>
                    </div>
					
					 <div class="col-lg-6 col-md-6">
                        <div class="about-content">
                           <h2>Mission</h2>
                            <p style="line-height: 2;">Our Mission is to provide Continuous Value Addition to our Clients with the best and most innovative technologies by Delivering Excellent Business Solutions. Our aim is to provide cost effective, simple but strong web solutions-all in a bid to push forward your unique Identity. Our vision is to provide Best-in-Class IT and IT enabled innovative, cost effective and timely solutions to clients all over the world as a one-stop shop for all web-based services.</p>
                        </div>
                    </div>
					
                </div>

            </div>

        </section><!-- #about -->

       
   
  </main>
    <!--==========================
    Footer
  ============================-->
  <?php include("part/footer.php"); ?>
  <!-- #footer -->

   

</body>


</html>