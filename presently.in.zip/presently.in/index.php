<!DOCTYPE html>
<html lang="en">


<head>
    <title>Presently Solutions | Software Development Company</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="At Presently, we make BRANDS AND BUSINESSES achieve exponential success by effectively leveraging the combined power of Mobile, Social Media, Web, Videos and Data Analytics to excite and engage consumers." property="description">
    <meta name="author" content="Presently Solutions" property="author">
    <meta name="canonical" content="https://presently.in/" property="canonical">
    <meta name="robots" content="Index, follow">
    <meta name="og:title" content="Presently Solutions:Top IT Company " property="og:title">
    <meta name="og:description" content="Presently Solutions software development company in Bhopal,India" property="og:description">
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <meta name="keywords" content="Leading It company in Bhopal,Customized software service,Web design and development,
         mobile app development, Software solutions,app developers, web application and development, leading software solution provider in Bhopal,India,Dynamic Websites,Bhopal web development, Bhopal mobile app development, Bhopal app developer, Bhopal web design, Bhopal logo design,
         US based IT company in Thrissur,Custom developed websites,WebSite Hosting,software support and solutions in Bhopal,India,
         Professionals in software development, Best software company in Central India " property="keywords">
    <meta name="keyphrase" content="Best Software company in thrissur, Top IT company in Bhopal,software solutions,
                Website design and development company Bhopal,IOS and Andoird application development company Thrissur" />
    <meta name="topic" content="Software"/>
    <meta name="subject" content="Software" />
    <meta name="classification" content="Software,Website development,Leading,Best,Top Company" />
    <meta name="rating" content="general">
    <meta name="audience" content="all" />
    <meta property="og:type" content="Software Company" />
    <meta property="og:url" content="https://www.facebook.com/presentlysolutions/" />
    <meta property="og:site_name" content="www.Presently.in" />
    <meta name="og:image" content="img/companyculture.png" />
    <meta name="og:email" content=" info@presently.in" />
    <meta name="og:phone_number" content="+919993357325" />
    <meta itemprop="name" content="Software Company, Bhopal" />
    <meta itemprop="description" content="Presently Soultions is the top web designing and web development in Bhopal who offers attractive website designs with creative web designers in Bhopal" />
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <link rel="canonical" href="index.php" />
    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <link href="img/apple-touch-icon.html" rel="apple-touch-icon">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700" rel="stylesheet">
    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.0-beta2/css/bootstrap-grid.min.css" integrity="sha512-moLwE39aHmOrh2go4i0UKv4RvOqS4V42zyyIUjGDbL5fOymDSMJSOxZGl+jgccLh8cVzzu9tKSuDhBvq7RJ6wA==" crossorigin="anonymous" />
    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./css/custom.css">
    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">
    <!-- font awsome cdn -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">

    <script src="../www.google.com/recaptcha/api.js"></script>

    <style>
        @media only screen and (min-width: 768px) {
            .servicemenu {
                position: static !important;
            }

            .servicemenu .megamenu {
                width: 100%;
                left: 0px;
            }

            .servicemenu .megamenu li {
                width: 25%;
                padding: 2px 10px !important;
                float: left;
                margin: 0px !important;
            }

            .servicemenu .megamenu li a {
                font-size: 12px;
                padding: 0px 20px;
            }

            .nav-menu li:hover ul.dropdown {
                display: block;
                /* Display the dropdown */
            }

            .inner-banner {

                padding: 43px;
                padding-top: 80px;
                padding-bottom: 90px;
                background-image: url("img/b1.jpg");
                -webkit-background-size: cover;
                -moz-background-size: cover;
                -o-background-size: cover;
                background-size: cover;
            }

            #main {
                margin-top: 130px;
            }

            .call-div {
                display: none
            }

            .text-center {
                text-align: center;
            }

            .box {
                background-color: red;
            }

            .inner-banner .box {
                display: inline-block;
                border: 3px solid #fff;
                padding: 11px 47px;
            }

            .inner-banner h3 {
                margin: 0;
                font-size: 40px;
                line-height: 42px;
                color: #fff;
                font-weight: 700;
            }



            @media (max-width:800px) {
                .inner-banner h3 {
                    font-size: 25px;
                }

                .inner-banner {
                    padding-top: 40px;
                    padding-bottom: 40px;
                    padding: 30px;
                }

                #main {
                    margin-top: 80px;
                }

                .call-div {
                    display: block !important;
                    bottom: 0px;
                    position: fixed;
                    width: 100%;
                    z-index: 1000;
                    bottom: 0;
                    background: white;
                    text-align: center;
                    padding: 10px;
                    color: Black;
                }

                .call-div a {
                    color: #90b777;
                }

                .contactspp {
                    display: none;
                }

                .whatspp {
                    display: block;
                    position: fixed;
                    bottom: 15%;
                    left: 0%;
                    height: 70px;
                    height: 70px;
                    width: 70px;
                    left: auto;
                    z-index: 111;
                }

                .whatspp img {
                    height: 50px;
                    width: 50px;
                }

            }
    </style>


<body>
    <header id="header">

        <div id="topbar">
            <div class="container">
                <div class="social-links">
                    <a><b> +91-9993357325</b></a>
                    <a target="_blank" href="https://www.facebook.com/presentlysolutions" class="facebook"><i class="fa fa-facebook"></i></a>
                    <a target="_blank" rel="nofollow" href="https://www.linkedin.com/company/presentlysolutions/" class="linkedin"><i class="fa fa-linkedin"></i></a>
                    <a target="_blank" href="https://www.twitter.com/presentlyindia" class="twitter"><i class="fa fa-twitter"></i></a>
                    <a rel="nofollow" target="_blank" href="https://www.instagram.com/presentlysolutions" class="instagram"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
        </div>

        <div class="container">

            <div class="logo float-left">
                <!-- comment below if you prefer to use an image logo -->
                <a href="#header " class="scrollto"><img src="img/logo.png" alt="" class="img-fluid"><b style="font-size:18px;"> Presently Solutions</b></a>
            </div>


            <nav class="main-nav float-right d-none d-lg-block">
                <ul>
                    <li class="active"><a href="index.php">Home</a></li>

                    <li class="drop-down" style="padding-left:2px;"><a href=" #ser2 ">About Us</a>
                        <ul>
                            <li><a href="portfolio.php">Portfolio</a></li>

                            <li><a href="Who-We-Are.php">Who We Are</a></li>
                            <li><a href="our-team.php">Our Team</a></li>
                            <li><a href="career.php">Career</a></li>
                        </ul>
                    </li>
                    <li class="drop-down servicemenu">
                        <a href="services.html">
                            Services</a>

                        <ul class="megamenu">
                            <li>

                            <li style="color: #413e66;">
                                <h3> Digital Services</h3>
                            </li>
                            <li style="color: #413e66;">
                                <h3> Services</h3>
                            </li>
                            <li style="color: #413e66;">
                                <h3> Other Services</h3>
                            </li>
                            <li style="color: #413e66;">
                                <h3> Products</h3>
                            </li>

                            <li> <a href="#" style="pointer-events: none;">Website Development</a></li>

                            <li style="pointer-events: none;"><a href="#">ERP SOFTWARE</a></li>

                            <li style="pointer-events: none;"> <a href="#">Online Reputation Management</a></li>

                            <li style="pointer-events: none;"><a href="#">WEB APPLICATIONS</a></li>

                            <li style="pointer-events: none;"><a href="#">CRM SOFTWARE </a></li>

                            <li style="pointer-events: none;"> <a href="#">Web Design</a></li>

                            <li style="pointer-events: none;"><a href="#">HRM SOFTWARE</a></li>

                            <li style="pointer-events: none;"><a href="#">GRAPHICS & LOGO DESIGNING</a></li>

                            <li style="pointer-events: none;"> <a href="#">Affiliate Marketing</a></li>

                            <li style="pointer-events: none;"><a href="#">Facebook Marketing Agency</a></li>

                            <li style="pointer-events: none;"><a href="#">ERP SOFTWARE</a></li>

                            <li style="pointer-events: none;"> <a href="#">DIGITAL MARKETING</a></li>

                            <li style="pointer-events: none;"> <a href="#">Brand Promotion</a></li>

                            <li style="pointer-events: none;"> <a href="#">Twitter Promotion</a></li>

                            <li style="pointer-events: none;"><a href="#">CRM SOFTWARE</a></li>

                            <li style="pointer-events: none;"> <a href="#">LinkedIn Promotion</a></li>

                            <li style="pointer-events: none;"> <a href="#">Video Promotion</a></li>

                            <li style="pointer-events: none;"> <a href="#">Keyword Analysis</a></li>

                            <li style="pointer-events: none;"><a href="Email_Marketing.php">SM SOFTWARE</a></li>

                            <li style="pointer-events: none;"> <a href="#">DOMAIN & HOSTING </a></li>

                            <li style="pointer-events: none;"> <a href="#">Local Search Marketing</a></li>
                            <li style="pointer-events: none;"><a href="#">More</a></li>

                        </ul>
                    </li>




                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </nav><!-- .main-nav -->
        </div>
    </header>
    <!-- #header -->
    <!--Talk to an expert-->
    <form name="expert-talk" action="contact-post.php" method="post">

        <div class="modal fade" id="myModalExpert" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Book Free Consultation</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <hr />
                        <!-- <b><i>Referral Information</i></b> -->
                        <div class="container">
                            <div class="form-group">
                                <input type="text" class="form-control" id="refName" name="name" placeholder="Enter Name">
                                <div id="reName"></div>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="position" name="position" placeholder="Enter Position">
                                <div id="rePosition"></div>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="refEmail" name="email" placeholder="Enter Email">
                                <div id="reEmail"></div>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter Number">
                                <div id="reNumber"></div>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="city" name="city" placeholder="Enter city">
                                <div id="reCity"></div>
                            </div>
                            <div class="form-group">
                                <textarea type="text" class="form-control" name="message" placeholder="Enter message" rows="5" id="refMessage"></textarea>
                                <div id="reMsg"></div>
                            </div>
                        </div>
                    </div>

                    <div class="container">
                        <div class="form-group col-md-12">
                            <div class="g-recaptcha" data-sitekey="6LcK4q0UAAAAAMWxo3xAXxeU7ckz5NTSQz_5va_k"></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" name="submit" class="btn btn-success" onclick="return validateRequest()" />
                        <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </form>






    <!--==========================
    Intro Section
  ============================-->
    <section id="intro" class="clearfix">
        <div class="container d-flex h-100">
            <div class="row justify-content-center align-self-center">
                <div class="col-md-6 intro-info order-md-first order-last">
                    <h2>Presently Solutions<br><span>Simple Touch, Infinite Possibilities</span></h2>
                    <h3><span>We help propel business ideas into full-blown technology solutions</span></h3>

                    <div class="expert-talk">
                        <button class="btn-get-started scrollto" data-toggle="modal" data-target="#myModalExpert">
                            TALK TO AN EXPERT
                        </button>
                    </div>
                </div>

                <div class="col-md-6 intro-img order-md-last order-first">
                    <img src="img/Functional-Navigation-For-Your-Website.png" alt="" class="img-fluid">
                </div>
            </div>

        </div>

        <!--==========================
      Technologies Section
    ============================-->
        <div class="container">
            <div class="owl-carousel clients-carousel">
                <img src="img/logos/angular.png" style="width:150px;padding:20px" alt="">
                <img src="img/logos/html1.png" style="width:150px;padding:20px" alt="">
                <img src="img/logos/ios.png" style="width:80px;padding:1px 0px;" alt="">
                <img src="img/logos/android.png" style="width:80px;padding:1px 0px" alt="">
                <img src="img/logos/php.png" style="width:100px;padding:10px" alt="">
                <img src="img/logos/css.png" style="width:80px;padding:10px" alt="">
                <img src="img/logos/laravel.png" style="width:160px;padding:20px" alt="">
            </div>
        </div>
    </section>

    <main id="main">

        <!--==========================
      About Us Section
        ============================-->
        <section id="about">

            <div class="container">
                <div class="row">

                    <div class="col-lg-5 col-md-6">
                        <div class="about-img mt-5">
                            <img src="img/companyculture.png" alt="">
                        </div>
                    </div>

                    <div class="col-lg-7 col-md-6 about">
                        <div class="about-content">
                            <h2>About Us</h2>
                            <p style="line-height: 2;">Founded in 2018 in Bhopal, India, Presently It started as a web
                                development
                                company and quickly moved into the mobile development market. Today we are a full-cycle
                                service provider
                                with a dedicated development team with expertise in web & mobile development, project
                                management,
                                digital design, technical support and quality assurance. Our sales, marketing and
                                business management
                                team is spread out throughout the united states. Collaboratively, we are passionate
                                about delivering
                                finished products that exceed our customer expectations. We are continuously evolving
                                and entering new
                                markets with hopes to stay ahead in the disruptive technology space!</p>
                        </div>
                    </div>
                </div>

            </div>

        </section><!-- #about -->

        <!--==========================
      Features Section
     ============================-->
        <section id="features">
            <div class="container">
                <div class="row feature-item mt-5 pt-5">
                    <div class="col-lg-6 wow fadeInUp order-1 order-lg-2 img">
                        <img src="img/android-app-development-2.png" class="img-fluid " alt="">
                    </div>

                    <div class="col-lg-6 wow fadeInUp pt-4 pt-lg-0 order-2 order-lg-1 life-cycle">
                        <h4>We are committed to giving 100% to each project.</h4>
                        <p style="line-height: 2;">
                            Our experts focus on developing websites that are capable to transform and lift the Brand. We provide user interface experience with fully customizable websites. We follow best practices that give you a great user experience with a page depth not more than 3 clicks away and craft the websites in such a pattern that increases your dwell time the time visitors spend on our site.
                        </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3" style="text-align: -webkit-center">
                        <div class="solution_box">
                            <i class="fa fa-group" style="color:#158ffd;padding-bottom: 10px"></i>

                            <h4>Client Relationship</h4>
                            <p style="text-align:justify">
                                Our solutions are developed to help our clients, maximize the impact of their
                                investment.

                            </p>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-sm-30 mt-xs-30" style="text-align: -webkit-center">
                        <div class="solution_box ">

                            <i class="fa fa-user" style="color:#158ffd;padding-bottom: 10px"></i>

                            <h4>End User</h4>
                            <p style="text-align:justify">
                                We love the communities we serve and pay particular attention to the end users.
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-sm-30 mt-xs-30" style="text-align: -webkit-center">
                        <div class="solution_box ">
                            <i class="fa fa-thumbs-up" style="color:#158ffd;padding-bottom: 10px"></i>
                            <h4>Our Goal</h4>
                            <p style="text-align:justify">
                                At the end of the day, our goal is to ensure that our clients can sit back with peace of
                                mind.
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-sm-30 mt-xs-30" style="text-align: -webkit-center">
                        <div class="solution_box ">
                            <i class="fa fa-star-o" style="color:#158ffd;padding-bottom: 10px"></i>
                            <h4>Latest Technology</h4>
                            <p style="text-align:justify">
                                Our technology team stays current with the latest technology trends.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section><!-- #about -->



        <!--==========================
      Services Section
        ============================-->
        <section id="services" class="section-bg">
            <div class="container">

                <header class="section-header">
                    <h3>Services</h3>
                    <p>Presently It has no limits when it comes to the industries we serve. We have provided everything from
                        Mock-Ups
                        to Full-Cycle Service Development solutions. Here are highlights of some services we currently
                        provide or
                        simply
                        <!-- <a href="contact.php#contact"> -->
                        <a href="#footer">
                            <b>CONTACT US</b></a> .
                    </p>
                </header>

                <div class="row">

                    <div class="col-md-6 col-lg-6 wow bounceInUp" data-wow-delay="0.1s" data-wow-duration="1.4s">
                        <div class="box">
                            <!-- <div class="icon" style="background: #e6fdfc;"><i class="ion-ios-paper-outline"
                  style="color: #3fcdc7;"></i></div> -->
                            <div class="icon" style="background: #fff0da;"><i class="
                        ion-ios-browsers" style="color: #413e66;"></i></div>

                            <h4 class="title"><a href="#"> Websites Development</a></h4>
                            <p class="description" style="text-align: justify">As the foundation of a digital presence,
                                a website
                                should be unique to a business.
                                Our custom coded websites are one-of-a-kind responsive designs and are of superior
                                quality. Our
                                dedicated team will custom code your website to look and function exactly the way you
                                want it. With only
                                the necessary code, custom developed websites load faster and are better optimized for
                                search-engine
                                optimization (SEO).After the website launch, our team is here to
                                support and maintain your website.</p>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-6 wow bounceInUp" data-wow-duration="1.4s">
                        <div class="box">
                            <div class="icon" style="background: #fff0da;"><i class="ion-ios-browsers-outline" style="color: #413e66;"></i></div>

                            <h4 class="title"><a href="#">Web Applications</a></h4>
                            <p class="description" style="text-align: justify">From start-ups to established businesses,
                                we work
                                closely and transparently with
                                our clients to better understand their goals and exceed their expectations. We utilize
                                new technologies,
                                enhanced frameworks and seasoned methodologies to develop apps that facilitate business
                                transformation
                                and growth. Front-end, full-stack, open-source, API, SAAS, E-Commerce - we develop it
                                all!</p>
                            <br />
                            <br />
                            <!-- <br />
              <br />
              <br />
              <br /> -->
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-6 wow bounceInUp" data-wow-delay="0.1s" data-wow-duration="1.4s">
                        <div class="box">
                            <div class="icon" style="background: #fff0da;"><i class="ion-ios-speedometer-outline" style="color:#413e66;"></i></div>
                            <h4 class="title"><a href="#">Business Analysis</a></h4>
                            <p class="description" style="text-align: justify">
                                Business analysis is a research discipline of identifying business needs and determining solutions to business problems. We love new innovative ideas and help our
                                clients grow
                                their ideas into full-blown
                                technology solutions. We understand that the IT market space is very competitive, but we
                                feel no idea is
                                “too ambitious”. Our experts assess all ideas through a comprehensive business analysis.
                                With major
                                industry leaders on our side, we have the best resources to advise clients on how to
                                optimize their
                                project architecture.
                                Business analysis is a research discipline of identifying business needs and determining solutions to business problems.
                                <!--  -->
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Consectetur, reiciendis?Lorem ipsum dolor sit
                            </p>

                        </div>
                    </div>

                    <div class="col-md-6 col-lg-6 wow bounceInUp" data-wow-duration="1.4s">
                        <div class="box">
                            <div class="icon" style="background: #fff0da;"><i class="ion-ios-browsers-outline" style="color: #413e66;"></i></div>

                            <h4 class="title"><a href="#">Wordpress Service</a></h4>
                            <p class="description" style="text-align: justify">The demand for WordPress website development is currently on the top of the list and increase continuously. Among all content management system, it covers about 60% of the market share. With all such higher ration, we Mindtech is WordPress Development Company provides you best WordPress Website Development Services. We focus on uniqueness, high-quality product, best output, and flexibility in WordPress Development. From small to large or medium scale business, we have the respective development package that fits in your budget without compromising the quality.</p>
                            <br/>
                            <br/>
              <br/>
              <br/>
              <br/> -->
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 wow bounceInUp" data-wow-duration="1.4s">
                        <div class="box mobile ">
                            <div class="icon" style="background: #fff0da;">
                                <!-- <i class="ion-ios-bookmarks-outline" style="color: #e98e06;"></i> -->
                                <i class="ion-android-phone-portrait" style="color: #413e66;"></i>

                            </div>
                            <h4 class="title "><a href="#">Mobile Development</a></h4>
                            <p class="description" style="text-align: justify">Our team
                                has mastered the art of developing our clients plans and visions into customized app
                                solutions while
                                keeping the
                                budget in mind. Before our clients invest in building their dream app, we assess if an
                                app idea can stay
                                competitive
                                or even survive in the mobile marketplace. Not only does our dedicated team craft UX/UI
                                designs and
                                develop on
                                iOS,Android and HTML 5 ,but we will also ensure proper app store submission.
                                To document the business requirements for the IT system support using appropriate documentation standards.</p>

                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 wow bounceInUp" data-wow-duration="1.4s">
                        <div class="box mobile ">
                            <div class="icon" style="background: #fff0da;">

                                <i class="fas fa-cloud-upload-alt" style="color: #413e66;"></i>

                            </div>
                            <h4 class="title "><a href="#">Web Hosting</a></h4>
                            <p class="description" style="text-align: justify">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Obcaecati praesentium iusto reiciendis ratione, doloribus deserunt tenetur explicabo adipisci consequuntur recusandae fugiat perferendis veritatis quae animi! Vel, minus eius. Vel, officiis.
                                Doloribus eos repellat laboriosam provident eligendi distinctio non amet, ex sit quibusdam in illum maiores ea ab quidem quam dignissimos nobis iure incidunt aut assumenda voluptate? Fugiat, beatae odio? Magnam.
                                Distinctio vero nam aliquid sunt vel quae, minus eaque autem obcaecati. Lorem ipsum dolor sit amet c
                        </div>
                    </div>




                </div>

            </div>
        </section>
        <!-- Modal ui/ux developement -->
        <div class="modal fade" id="myModalU" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">UI/UX DEVELOPMENT</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body scroll">
                        <p>&nbsp;&nbsp;&nbsp;We make things look pretty and ensure it meets all the necessary
                            micro-interactions
                            with our extensive
                            experience in wire-framing and business logic design for intuitive and useful products!</p>
                        <hr>
                        <p class="sub_heading">Our UX/UI Design Services Include:</p>
                        <ul class="sub_points">
                            <li>Interaction Design</li>
                            <li>Wire frames & Prototypes</li>
                            <li>Information Architecture</li>
                            <li>User Research & Usability Testing</li>
                            <li>Visual, Color and Graphic Design</li>
                            <li>Branding, Layouts & Typography</li>
                            <li>User Guides</li>
                        </ul>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal iOS -->
        <div class="modal fade" id="myModalI" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">

                        <h4 class="modal-title">IOS DEVELOPMENT</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>&nbsp;&nbsp;&nbsp;Apple apps offer some of the best user-experience and interface for a
                            variety of user
                            needs. Whether
                            it is for enterprise or consumer use, we can help design, develop and get iOS applications
                            approved in the
                            app store.</p>
                        <hr>
                        <p class="sub_heading">Our iOS Services Include:</p>
                        <ul class="sub_points">
                            <li>Mobile Prototyping</li>
                            <li>Front-End Storyboarding</li>
                            <li>Objective-C and Swift Programming</li>
                            <li>Field Service Apps</li>
                            <li>Enterprise & Business productivity</li>
                            <li>Gaming, Entertainment, Music & Media</li>
                            <li>GPS Based / Augmented Reality Apps</li>
                            <li>Subscription based</li>
                            <li>Custom Web Services & APIs</li>
                        </ul>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal ui/ux developement -->
        <div class="modal fade" id="myModalA" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">

                        <h4 class="modal-title">ANDROID DEVELOPMENT</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>&nbsp;&nbsp;&nbsp;Androids are the most widely used devices but unlike iOS, requires Google
                            Play
                            licensing for paid applications.
                            We are here to help our clients take their enterprise or consumer app idea and put a
                            fully-functioning
                            product into
                            their android users’ hands.</p>
                        <hr>
                        <p class="sub_heading">Our Android Services Include:</p>
                        <ul class="sub_points">
                            <li>Android Mobile Prototying</li>
                            <li>Custom Web Services & APIs</li>
                            <li>Java Programming and Android SDK</li>
                            <li>Android UI/UX Design</li>
                            <li>Google Play Submission</li>
                        </ul>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal ui/ux developement -->
        <div class="modal fade" id="myModalH" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">

                        <h4 class="modal-title">HTML5</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>&nbsp;&nbsp;&nbsp;HTML5 allows an app to run on multiple devices at once. We help our clients
                            deliver to
                            more users with
                            our cross-platform app development expertise in HTML5. </p>

                        <hr>
                        <p class="sub_heading">Our HTML5 Services Include:</p>
                        <ul class="sub_points">
                            <li>jQuery Mobile</li>
                            <li>Custom Web Services & APIs</li>
                            <li>JavaScript and Sencha Touch</li>
                            <li>PhoneGap & Cordova</li>
                            <li>HTML5 design, animations, and transitions</li>
                            <li>Titanium</li>
                        </ul>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- #services -->
        <!--==========================
      Why Us Section
        ============================-->

        <section id="why-us" class="wow fadeIn">
            <div class="container">

                <header class="section-header">

                    <h3>Why choose us?</h3>
                    <p>From establishing requirements, a budget, and timelines early on, we are able to deliver the most
                        productive, innovative, and cost-effective solutions for your project. Building a dream software
                        might seem
                        overwhelming. With Presently It, clients have felt at ease about getting their ideas, budgets, and
                        resources
                        actualized into their ideal product- all within realistic deadlines. Our goal is to make our
                        clients’
                        products a gold standard within their respective industries. We are happy to provide our
                        full-cycle
                        solutions at low-costs to encourage return-clients and referrals!</p>


                    <div class="row">

                        <div class="col-lg-4">
                            <div class="why-us-img">
                                <img src="img/dashboard-example-desktop.png" alt="" class="img-fluid">
                            </div>
                        </div>

                        <div class="col-lg-8">
                            <div class="why-us-content">
                                <div class="features wow bounceInUp clearfix">
                                    <i class="fa fa-diamond" style="color: #589af1;"></i>
                                    <h4>Presently It Advantage</h4>
                                </div>

                                <ul style="line-height: 2;">
                                    <li><i class="ion-android-checkmark-circle" style="color: #589af1;"></i>
                                        Significantly reduce project costs of clients</li>
                                    <li><i class="ion-android-checkmark-circle" style="color: #589af1;"></i>
                                        Seamlessly scale up development efforts</li>
                                    <li><i class="ion-android-checkmark-circle" style="color: #589af1;"></i> Maintain
                                        reliable long-term
                                        relationships </li>
                                    <li><i class="ion-android-checkmark-circle" style="color: #589af1;"></i> We serve all
                                        size industries
                                        and
                                        businesses</li>

                                </ul>
                            </div>
                        </div>
                    </div>

            </div>

        </section>

        <!--==========================
      Work process Section
     ============================-->

        <section id="call-to-action" class="wow fadeInUp">
            <div class="container">
                <h3 class="cta-title ">Work Process</h3>

                <div class="row">
                    <div class="col-lg-2 col-md-6 text-center text-lg-left">
                        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="50" height="50" viewBox="0 0 172 172" style="fill:#000000;align-content: center">
                            <g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal">
                                <path d="M0,172v-172h172v172z" fill="none"></path>
                                <g fill="#ffffff">
                                    <g id="surface1">
                                        <path d="M83.3125,10.75c-28.15576,0 -51.0625,22.90674 -51.0625,51.0625c0,13.36401 7.47461,23.34766 14.70776,33.00586c5.77393,7.71607 11.21191,15.0647 12.16724,23.43164v18.8125c0,9.45874 7.02319,17.29028 16.125,18.60254v2.89746c0,2.96045 2.41455,5.375 5.375,5.375h5.375c2.96045,0 5.375,-2.41455 5.375,-5.375v-2.89746c9.10181,-1.31226 16.125,-9.1438 16.125,-18.60254v-16.39795c0.04199,-9.39575 5.97339,-17.38477 12.26172,-25.84619c7.19116,-9.6582 14.61328,-19.64185 14.61328,-33.00586c0,-28.15576 -22.90674,-51.0625 -51.0625,-51.0625zM83.3125,16.125c25.19531,0 45.6875,20.49219 45.6875,45.6875c0,11.58984 -6.88672,20.84912 -13.54248,29.80396c-6.02588,8.10449 -12.24072,16.45044 -13.20654,26.46558h-16.25098v-7.89453c0,-1.48022 -1.20728,-2.6875 -2.6875,-2.6875c-1.48022,0 -2.6875,1.20728 -2.6875,2.6875v7.90503h-16.05151c-0.97632,-10.01514 -7.24365,-18.38208 -13.31152,-26.49707c-6.70825,-8.95483 -13.63696,-18.20361 -13.63696,-29.78296c0,-25.19531 20.49219,-45.6875 45.6875,-45.6875zM82.94507,24.177c-7.18066,0.06299 -14.19336,2.1731 -20.29272,6.18335c-1.23877,0.80835 -1.57471,2.47754 -0.75586,3.71631c0.5144,0.78735 1.36475,1.20727 2.23608,1.20727c0.51441,0 1.01831,-0.13647 1.48023,-0.44092c6.9602,-4.57715 15.32715,-6.25684 23.56811,-4.74512c1.46973,0.26245 2.86597,-0.70337 3.12842,-2.1626c0.27295,-1.45923 -0.69287,-2.85547 -2.1521,-3.11792c-2.40405,-0.45142 -4.8081,-0.66138 -7.21216,-0.64038zM101.74707,29.22656c-1.02881,-0.14697 -2.11011,0.32544 -2.6875,1.27026c-0.76636,1.28076 -0.35693,2.92896 0.92383,3.69531c2.21509,1.34375 4.2832,2.96045 6.13086,4.8186c0.5249,0.5249 1.21777,0.78735 1.90015,0.78735c0.69287,0 1.38574,-0.26245 1.91065,-0.78735c1.0498,-1.0498 1.0498,-2.75049 0,-3.80029c-2.1731,-2.1626 -4.57715,-4.05225 -7.17017,-5.61646c-0.31494,-0.18897 -0.66138,-0.31494 -1.00781,-0.36743zM13.50049,30.93774c-1.0498,0.02099 -2.03662,0.65088 -2.45654,1.67969c-0.5459,1.37524 0.11548,2.94995 1.49072,3.49585l9.97314,4.03125c0.32544,0.13647 0.66138,0.19946 0.99732,0.19946c1.0603,0 2.07861,-0.64038 2.49853,-1.67969c0.5564,-1.38574 -0.11548,-2.94995 -1.49072,-3.50635l-9.96265,-4.03125c-0.34644,-0.13647 -0.70337,-0.19946 -1.0498,-0.18896zM153.12451,30.93774c-0.34644,-0.0105 -0.70337,0.05249 -1.0498,0.18896l-9.96265,4.03125c-1.37524,0.5564 -2.04712,2.12061 -1.49072,3.50635c0.41992,1.03931 1.43823,1.67969 2.49853,1.67969c0.33594,0 0.67188,-0.06299 0.99732,-0.19946l9.97315,-4.03125c1.37524,-0.5459 2.03662,-2.1206 1.49072,-3.49585c-0.41992,-1.02881 -1.40674,-1.65869 -2.45654,-1.67969zM2.6875,59.125c-1.48022,0 -2.6875,1.20728 -2.6875,2.6875c0,1.48022 1.20728,2.6875 2.6875,2.6875h16.125c1.48022,0 2.6875,-1.20728 2.6875,-2.6875c0,-1.48022 -1.20728,-2.6875 -2.6875,-2.6875zM147.8125,59.125c-1.48022,0 -2.6875,1.20728 -2.6875,2.6875c0,1.48022 1.20728,2.6875 2.6875,2.6875h16.125c1.48022,0 2.6875,-1.20728 2.6875,-2.6875c0,-1.48022 -1.20728,-2.6875 -2.6875,-2.6875zM72.5625,69.875c-0.68237,0 -1.37524,0.26245 -1.90015,0.78735c-1.0498,1.0498 -1.0498,2.75049 0,3.80029l5.375,5.375c0.5249,0.5249 1.20728,0.78735 1.90015,0.78735c0.69287,0 1.37524,-0.26245 1.90015,-0.78735c1.0498,-1.0498 1.0498,-2.75049 0,-3.80029l-5.375,-5.375c-0.5249,-0.5249 -1.21777,-0.78735 -1.90015,-0.78735zM94.0625,69.875c-0.68237,0 -1.37524,0.26245 -1.90015,0.78735l-10.75,10.75c-0.50391,0.50391 -0.78735,1.18628 -0.78735,1.90015v16.125c0,1.48022 1.20728,2.6875 2.6875,2.6875c1.48022,0 2.6875,-1.20728 2.6875,-2.6875v-15.01221l9.96265,-9.96265c1.0498,-1.0498 1.0498,-2.75049 0,-3.80029c-0.5249,-0.5249 -1.21777,-0.78735 -1.90015,-0.78735zM23.55762,83.28101c-0.35693,0 -0.71387,0.06299 -1.0498,0.19946l-9.97314,4.03125c-1.37524,0.5459 -2.03662,2.12061 -1.49072,3.49585c0.43042,1.0498 1.43823,1.67969 2.49854,1.67969c0.33594,0 0.68237,-0.06299 1.00781,-0.18896l9.96265,-4.03125c1.37524,-0.5564 2.04712,-2.12061 1.49072,-3.50635c-0.41992,-1.02881 -1.40674,-1.65869 -2.44604,-1.67969zM143.06738,83.29151c-1.03931,0.02099 -2.02612,0.65088 -2.44604,1.67969c-0.5564,1.37524 0.11548,2.94995 1.49072,3.50635l9.96265,4.02075c0.32544,0.13647 0.67188,0.18896 1.00781,0.18896c1.0603,0 2.06811,-0.62988 2.49853,-1.67969c0.5459,-1.37524 -0.11548,-2.93945 -1.49072,-3.49585l-9.97315,-4.03125c-0.33594,-0.13647 -0.69287,-0.19946 -1.0498,-0.18896zM64.5,123.625h37.625v3.00244l-37.625,4.70313zM102.125,132.04443v5.01807c0,0.10498 -0.03149,0.20996 -0.03149,0.32544l-27.29492,3.41186c-1.46973,0.17847 -2.50903,1.52222 -2.32007,2.99194c0.16797,1.36475 1.32276,2.35156 2.65601,2.35156c0.11548,0 0.22046,0 0.33594,-0.02099l25.22681,-3.14941c-2.19409,4.44067 -6.72925,7.5271 -12.00977,7.5271h-10.75c-7.41162,0 -13.4375,-6.02588 -13.4375,-13.4375v-0.31494zM80.625,155.875h5.375v2.6875h-5.375z">
                                        </path>
                                    </g>
                                </g>
                            </g>
                        </svg><br>
                        <p class="cta-text">Tell us your idea</p>
                    </div>
                    <div class="col-lg-3 col-md-6 text-center text-lg-left">
                        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="50" height="50" viewBox="0 0 172 172" style=" fill:#000000;">
                            <g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal">
                                <path d="M0,172v-172h172v172z" fill="none"></path>
                                <g fill="#ffffff">
                                    <g id="surface1">
                                        <path d="M85.68926,25.8c-8.39004,0 -15.83945,2.72109 -21.21445,7.62578c-1.11699,1.02461 -2.1248,2.1668 -3.04863,3.36777c-2.18359,-1.33535 -5.16504,-2.39355 -9.01153,-2.39355c-6.85312,0 -12.98398,2.23399 -17.40996,6.29043c-4.41758,4.06484 -7.05469,9.93535 -7.05469,16.79688c0,4.46797 1.13379,12.55566 1.75527,17.01524c-0.98262,0.83984 -1.75527,1.91484 -1.75527,3.32578c0,1.17578 0.32754,1.94844 0.57109,2.73789c0.12598,0.40312 0.24355,0.75586 0.31074,1.01621c0.07559,0.26035 0.06719,0.5375 0.06719,0.11758c0,2.09121 1.65449,3.47695 3.56094,3.93047c0.49551,5.62695 3.19981,10.58203 7.31504,13.9834v8.52441c-1.14219,0.37793 -7.21426,2.32637 -14.47891,5.9209c-3.96406,1.95684 -7.96172,4.25801 -11.08594,6.87832c-3.12422,2.61191 -5.61016,5.65215 -5.61016,9.34746v7.31504h25.8v8.6h103.2v-8.6h25.8v-7.31504c0,-3.69531 -2.48594,-6.73555 -5.61016,-9.34746c-3.12422,-2.62031 -7.12187,-4.92148 -11.08594,-6.87832c-7.26465,-3.59453 -13.33672,-5.54297 -14.47891,-5.9209v-8.52441c4.11524,-3.40137 6.81953,-8.35644 7.31504,-13.9834c1.90645,-0.45351 3.56094,-1.83926 3.56094,-3.93047c0,0.41992 -0.0084,0.14277 0.06719,-0.11758c0.06719,-0.26035 0.18476,-0.61309 0.31074,-1.01621c0.24355,-0.78945 0.57109,-1.56211 0.57109,-2.73789c0,-1.41094 -0.78105,-2.48594 -1.76367,-3.32578c0.62988,-4.51836 1.76367,-12.74043 1.76367,-17.01524c0,-5.66055 -1.5957,-9.85976 -4.07324,-12.63125c-2.18359,-2.41875 -4.98027,-3.49375 -7.68457,-3.7709c-0.37793,-0.68027 -0.71387,-1.53691 -2.35156,-2.93945c-1.94844,-1.67129 -4.97187,-3.30059 -9.1459,-3.67012c-0.13437,-0.0168 -0.25195,-0.07559 -0.39473,-0.07559c-0.08398,0 -0.15957,0.04199 -0.24355,0.05039c-0.36113,-0.0168 -0.71387,-0.05039 -1.0918,-0.05039c-3.84648,0 -7.43262,0.73906 -10.65762,2.07441c-1.87285,-1.075 -3.91367,-1.6041 -5.9125,-1.80566c-0.5123,-0.97422 -1.35215,-2.37676 -3.09063,-3.99766c-2.6623,-2.46914 -7.11348,-4.87109 -13.71465,-4.87109zM85.68926,30.1c5.58496,0 8.81836,1.89805 10.79199,3.72891c1.96524,1.82246 2.55312,3.46016 2.55312,3.46016l0.5123,1.41094h1.50332c2.55312,0 5.13145,0.83984 7.15547,3.04024c2.02402,2.20039 3.59453,5.9041 3.59453,12.00976c0,4.8123 -1.31855,15.25996 -1.88125,19.39199l-0.20996,1.57051l1.42773,0.67188c0.42832,0.19316 0.66348,0.5375 0.66348,0.94063c0,0.03359 -0.20156,1.0918 -0.47031,2.01563c-0.14277,0.47031 -0.27715,0.93223 -0.40313,1.36895c-0.11758,0.43672 -0.24355,0.73066 -0.24355,1.45293c0,0.26875 -0.21836,0.5375 -0.65508,0.5375h-4.67793v2.95625c0,6.33242 -3.04863,11.90899 -7.74336,15.43633l-0.85664,0.64668v12.59766l1.45293,0.49551c0,0 9.01992,3.09063 17.97266,7.78535c4.47637,2.35156 8.92754,5.10625 12.13574,7.95332c3.2082,2.85547 4.98867,5.69414 4.98867,8.02891v4.3h-94.6v-4.3c0,-2.33476 1.78047,-5.17344 4.98867,-8.02891c3.2082,-2.84707 7.65937,-5.60176 12.13574,-7.95332c8.95273,-4.69472 17.97266,-7.78535 17.97266,-7.78535l1.45293,-0.49551v-12.58926l-0.85664,-0.64668c-4.69473,-3.53574 -7.74336,-9.1123 -7.74336,-15.44473v-2.95625h-4.67793c-0.43672,0 -0.65508,-0.26875 -0.65508,-0.5375c0,-0.72226 -0.12597,-1.01621 -0.24355,-1.45293c-0.12598,-0.43672 -0.26035,-0.89863 -0.40313,-1.36895c-0.26875,-0.92383 -0.47031,-1.98203 -0.47031,-2.01562c0,-0.39473 0.23516,-0.74746 0.65508,-0.94063l1.42773,-0.67187l-0.20996,-1.57051c-0.5627,-4.07324 -1.87285,-14.26055 -1.87285,-19.39199c0,-7.24785 2.6875,-13.05117 7.18066,-17.15801c4.48476,-4.09844 10.85078,-6.49199 18.30859,-6.49199zM52.41465,38.7c3.04024,0 5.16504,0.76426 6.70195,1.70488c-1.24297,2.34316 -2.1584,4.90469 -2.6791,7.66777c-0.31914,0.36953 -0.5375,0.83984 -0.5375,1.37734c0,0.31914 0.07559,0.61309 0.20156,0.88184c-0.12598,1.11699 -0.20156,2.25078 -0.20156,3.41816c0,2.09961 0.19316,4.70313 0.44512,7.35703c-0.26035,0.35274 -0.44512,0.76426 -0.44512,1.24297c0,0.62988 0.28555,1.18418 0.71387,1.57891c0.36953,3.32578 0.79785,6.55078 1.0918,8.70078c-1.01621,0.96582 -1.80566,2.18359 -1.80566,3.69531c0,1.26816 0.36113,2.25078 0.64668,3.225c0.14278,0.49551 0.28555,0.94902 0.36953,1.28496c0.09238,0.33594 0.10078,0.67188 0.10078,0.32754c0,2.6959 2.29278,4.8375 4.95508,4.8375h0.5459c0.12598,2.30117 0.61309,4.50156 1.35215,6.57598c-0.87344,0.27715 -1.52012,1.0582 -1.52012,2.02402c0,1.18418 0.96582,2.15 2.15,2.15c0.42832,0 0.80625,-0.15957 1.14219,-0.36953c0.90703,1.57051 1.98203,3.03184 3.225,4.35039c-0.0252,0.10918 -0.06719,0.20996 -0.06719,0.31914c0,1.18418 0.96582,2.15 2.15,2.15v7.12188c-1.39414,0.48711 -5.59336,2.00723 -10.91797,4.45957c0.10918,-0.26035 0.16797,-0.5375 0.16797,-0.83145c0,-1.18418 -0.96582,-2.15 -2.15,-2.15c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,0.99941 0.69707,1.80566 1.6209,2.04922c-1.21777,0.58789 -2.40195,1.14219 -3.69531,1.81406c-0.41992,0.22676 -0.83984,0.46191 -1.25137,0.69707c-0.30234,-0.15957 -0.62148,-0.26035 -0.97422,-0.26035c-1.13379,0 -2.04082,0.89024 -2.11641,2.00723c-3.14101,1.84766 -6.14766,3.88008 -8.65039,6.09726c-2.36836,2.10801 -4.35879,4.40918 -5.47578,6.94551h-7.40742c0,-1.18418 -0.96582,-2.15 -2.15,-2.15c-1.18418,0 -2.15,0.96582 -2.15,2.15h-8.6c0,-1.18418 -0.96582,-2.15 -2.15,-2.15v-0.86504c0,-1.6041 1.38574,-3.80449 4.07324,-6.05527c1.86445,-1.56211 4.26641,-3.09063 6.81113,-4.50996c-0.06719,0.20996 -0.13438,0.43672 -0.13438,0.68027c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-0.99101 -0.68867,-1.79726 -1.6125,-2.04082c0.29395,-0.14277 0.57109,-0.30234 0.86504,-0.44512c1.46133,-0.72226 2.88066,-1.35215 4.2748,-1.97363c0.24355,0.10078 0.50391,0.15957 0.77266,0.15957c0.89863,0 1.66289,-0.5459 1.98203,-1.32695c4.36719,-1.78887 7.74336,-2.92266 7.91133,-2.97305h1.93164v-8.92754c0.31914,0.19316 0.67188,0.32754 1.075,0.32754c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15c-0.40313,0 -0.75586,0.13438 -1.075,0.32754v-1.6293l-0.88184,-0.63828c-0.86504,-0.63828 -1.65449,-1.36894 -2.37676,-2.1584c0,-0.07559 0.03359,-0.13438 0.03359,-0.20156c0,-1.0582 -0.78105,-1.88965 -1.78047,-2.07441c-1.5873,-2.50273 -2.51953,-5.45898 -2.51953,-8.65039v-2.1752h-3.12422c-0.26035,0 -0.22676,-0.09238 -0.22676,0c0,-0.71387 -0.12597,-0.94063 -0.23516,-1.31016c-0.10078,-0.36113 -0.21836,-0.73066 -0.33594,-1.1002c-0.22676,-0.73066 -0.37793,-1.5957 -0.37793,-1.46133c0,-0.10078 0.05879,-0.25195 0.40312,-0.36113l1.68809,-0.57109l-0.10918,-0.80625c0.10918,-0.26035 0.16797,-0.5459 0.16797,-0.83984c0,-0.47871 -0.18476,-0.89863 -0.45351,-1.25137c-0.35274,-2.51953 -0.80625,-6.04687 -1.18418,-9.59941c0.93223,-0.24355 1.6377,-1.0498 1.6377,-2.04922c0,-1.13379 -0.89023,-2.04082 -2.00723,-2.11641c-0.06719,-0.99941 -0.14277,-2.04082 -0.14277,-2.74629c0,-2.20879 0.31074,-4.24121 0.89863,-6.08887c0.73066,-0.34434 1.25137,-1.0834 1.25137,-1.94844c0,-0.26035 -0.05879,-0.50391 -0.14277,-0.73906c0.78105,-1.54531 1.78047,-2.93945 2.97305,-4.15723c0.38633,0.36113 0.89863,0.59629 1.46973,0.59629c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-0.41152 -0.14277,-0.77266 -0.34434,-1.1002c3.2502,-2.04082 7.29824,-3.1998 11.90898,-3.1998zM36.55,81.7c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15c-1.18418,0 -2.15,0.96582 -2.15,2.15zM119.06465,38.7c3.57774,0 5.85371,1.0666 7.41582,2.22559c-0.99941,0.17637 -1.78047,1.01621 -1.78047,2.07441c0,1.18418 0.96582,2.15 2.15,2.15c1.03301,0 1.86445,-0.74746 2.06602,-1.72168c0.11758,0.19316 0.27715,0.46191 0.27715,0.46191l0.57109,1.25976h1.38574c1.88125,0 3.96406,0.73906 5.61855,2.58672c1.19258,1.31855 2.20879,3.27539 2.6791,6.07207c-1.03301,0.15117 -1.84766,1.00781 -1.84766,2.09121c0,1.17578 0.94902,2.1332 2.11641,2.15c-0.04199,2.05762 -0.36113,5.32461 -0.75586,8.75957c-0.79785,0.31914 -1.36055,1.0834 -1.36055,1.99043c0,0.70547 0.36113,1.30176 0.89024,1.69649c-0.20996,1.6209 -0.43672,3.56934 -0.58789,4.63594l-0.24355,1.76367l1.68809,0.57109c0.34434,0.11758 0.40313,0.26035 0.40313,0.36113c0,-0.13438 -0.15117,0.73066 -0.37793,1.46133c-0.03359,0.11758 -0.07559,0.23516 -0.10918,0.36113c-0.94903,0.21836 -1.66289,1.03301 -1.66289,2.04922h-2.15v2.1752c0,1.0918 -0.13438,2.15 -0.33594,3.18301c-0.37793,-0.62149 -1.03301,-1.0582 -1.81406,-1.0582c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c0.31914,0 0.62149,-0.07559 0.89863,-0.20156c-1.15059,2.75469 -3.01504,5.12305 -5.3918,6.86152l-0.88184,0.63828v8.0793c-0.31914,-0.19316 -0.67187,-0.32754 -1.075,-0.32754c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c0.40313,0 0.75586,-0.13437 1.075,-0.32754v2.47754h1.93164c0.05039,0.0168 1.34375,0.48711 1.88965,0.67188c-0.36953,0.38633 -0.59629,0.90703 -0.59629,1.47812c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-0.04199 -0.0252,-0.07559 -0.0252,-0.12598c2.6707,1.04141 5.97129,2.40195 9.37266,4.09004c2.01563,0.99941 4.00606,2.08281 5.84531,3.225c0.31074,0.82305 1.0834,1.41094 2.00723,1.41094c0.04199,0 0.08399,-0.0252 0.13437,-0.0252c0.80625,0.5627 1.55371,1.13379 2.24238,1.70488c0.81465,0.68027 1.46973,1.35215 2.04922,2.01563c-0.05879,0.19316 -0.12598,0.38633 -0.12598,0.60469c0,1.0918 0.82305,1.95684 1.87285,2.09121c0.17637,0.48711 0.27715,0.93223 0.27715,1.34375v3.01504h-4.3c0,-1.18418 -0.96582,-2.15 -2.15,-2.15c-1.18418,0 -2.15,0.96582 -2.15,2.15h-8.6c0,-1.18418 -0.96582,-2.15 -2.15,-2.15c-1.18418,0 -2.15,0.96582 -2.15,2.15h-0.95742c-0.68028,-1.54531 -1.67969,-3.00664 -2.90586,-4.39238c0.97422,-0.20156 1.71328,-1.02461 1.71328,-2.05762c0,-1.18418 -0.96582,-2.15 -2.15,-2.15c-1.03301,0 -1.86445,0.74746 -2.06601,1.72168c-0.0252,-0.0168 -0.04199,-0.04199 -0.06719,-0.06719c-3.64492,-3.2334 -8.33125,-6.09726 -12.99238,-8.54121c-3.13262,-1.6377 -5.98809,-2.94785 -8.56641,-4.06484c-0.10918,-1.0918 -0.99102,-1.94844 -2.10801,-1.94844c-0.50391,0 -0.94063,0.20156 -1.31016,0.49551c-2.41035,-0.97422 -4.3168,-1.68809 -5.13984,-1.97363v-0.67187c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15v-2.62871c3.94727,-3.28379 6.75234,-7.81895 7.89453,-12.99238c0.42832,-0.39473 0.70547,-0.94902 0.70547,-1.57891c0,-0.37793 -0.11758,-0.70547 -0.29395,-1.01621c0.04199,-0.37793 0.10918,-0.74746 0.12598,-1.13379h0.5459c1.69649,0 3.225,-0.87344 4.12363,-2.19199c1.0834,-0.10918 1.94844,-0.99102 1.94844,-2.10801c0,-0.66348 -0.31914,-1.24297 -0.79785,-1.6377c0.05039,-0.17637 0.09238,-0.31074 0.15117,-0.5123c0.28555,-0.97422 0.64668,-1.95684 0.64668,-3.225c0,-1.52012 -0.78945,-2.73789 -1.81406,-3.70371c0.05879,-0.44512 0.15117,-1.25977 0.22676,-1.78047c0.90703,-0.25195 1.5873,-1.0498 1.5873,-2.04082c0,-0.80625 -0.46191,-1.47813 -1.10859,-1.84766c0.5543,-4.52676 1.10859,-9.57422 1.10859,-13.20234c0,-3.40976 -0.45351,-6.33242 -1.26816,-8.80156c0.74746,-0.33594 1.26816,-1.0834 1.26816,-1.94844c0,-1.18418 -0.96582,-2.15 -2.15,-2.15c-0.32754,0 -0.63828,0.09238 -0.91543,0.22676c-0.29395,-0.48711 -0.61309,-0.94063 -0.94062,-1.36895c2.1416,-0.63828 4.46797,-1.00781 6.9707,-1.00781zM51.6,40.85c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM45.15,47.3c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM120.4,47.3c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM133.3,47.3c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM38.7,53.75c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM51.6,53.75c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM126.85,53.75c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM45.15,60.2c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM120.4,60.2c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM133.3,60.2c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM38.7,66.65c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM51.6,66.65c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM126.85,66.65c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM45.15,73.1c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM120.4,73.1c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM133.3,73.1c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM51.6,79.55c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM126.85,79.55c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM45.15,86c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM58.05,86c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM120.4,86c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM51.6,92.45c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM113.95,92.45c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM126.85,92.45c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM58.05,98.9c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM107.5,98.9c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM120.4,98.9c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM51.6,105.35c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM64.5,105.35c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM113.95,105.35c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM45.15,111.8c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM120.4,111.8c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM38.7,118.25c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM126.85,118.25c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM139.75,118.25c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM19.35,124.7c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM32.25,124.7c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15zM146.2,124.7c-1.18418,0 -2.15,0.96582 -2.15,2.15c0,1.18418 0.96582,2.15 2.15,2.15c1.18418,0 2.15,-0.96582 2.15,-2.15c0,-1.18418 -0.96582,-2.15 -2.15,-2.15z">
                                        </path>
                                    </g>
                                </g>
                            </g>
                        </svg><br>
                        <p class="cta-text">We'll discuss together</p>
                    </div>
                    <div class="col-lg-3 col-md-6 text-center text-lg-left">
                        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="45" height="45" viewBox="0 0 172 172" style=" fill:#000000;">
                            <g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal">
                                <path d="M0,172v-172h172v172z" fill="none"></path>
                                <g fill="#ffffff">
                                    <g id="surface1">
                                        <path d="M86,6.88c-43.65844,0 -79.12,35.46156 -79.12,79.12c0,43.65844 35.46156,79.12 79.12,79.12c43.65844,0 79.12,-35.46156 79.12,-79.12c0,-43.65844 -35.46156,-79.12 -79.12,-79.12zM86,13.76c39.93625,0 72.24,32.30375 72.24,72.24c0,39.93625 -32.30375,72.24 -72.24,72.24c-39.93625,0 -72.24,-32.30375 -72.24,-72.24c0,-16.89094 5.79156,-32.42469 15.48,-44.72h56.76v-6.88h-50.525c2.55313,-2.49937 5.2675,-4.78375 8.17,-6.88h42.355v-6.88h-30.6375c9.31219,-4.36719 19.65906,-6.88 30.6375,-6.88zM34.0775,48.16l8.9225,6.5575l-2.0425,2.795l38.1625,27.8425c-0.01344,0.215 0,0.43 0,0.645c0,3.80281 3.07719,6.88 6.88,6.88c3.35938,0 6.16781,-2.40531 6.7725,-5.59l32.465,-10.75l-2.15,-6.5575l-32.5725,10.965c-1.22281,-1.08844 -2.75469,-1.8275 -4.515,-1.8275v-3.44h-8.385l-9.46,-6.88h17.845v-6.88h-27.305l-9.3525,-6.88h36.6575v-6.88z">
                                        </path>
                                    </g>
                                </g>
                            </g>
                        </svg><br>
                        <p class="cta-text">Schedule Estimate</p>
                    </div>
                    <div class="col-lg-2 col-md-6 text-center text-lg-left">
                        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="45" height="45" viewBox="0 0 172 172" style=" fill:#000000;">
                            <g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal">
                                <path d="M0,172v-172h172v172z" fill="none"></path>
                                <g fill="#ffffff">
                                    <path d="M86,6.88c-0.17805,0.00415 -0.35551,0.02212 -0.53078,0.05375c-43.4081,0.29358 -78.58922,35.58971 -78.58922,79.06625c0,43.6583 35.4617,79.12 79.12,79.12c43.6583,0 79.12,-35.4617 79.12,-79.12c0,-43.47198 -35.17396,-78.76536 -78.57578,-79.06625c-0.17969,-0.03233 -0.36167,-0.0503 -0.54422,-0.05375zM86,13.76c39.94058,0 72.24,32.29942 72.24,72.24c0,39.94058 -32.29942,72.24 -72.24,72.24c-39.94058,0 -72.24,-32.29942 -72.24,-72.24c0,-39.94058 32.29942,-72.24 72.24,-72.24zM58.48,61.92c-5.69958,0 -10.32,4.62042 -10.32,10.32c0,5.69958 4.62042,10.32 10.32,10.32c5.69958,0 10.32,-4.62042 10.32,-10.32c0,-5.69958 -4.62042,-10.32 -10.32,-10.32zM113.52,61.92c-5.69958,0 -10.32,4.62042 -10.32,10.32c0,5.69958 4.62042,10.32 10.32,10.32c5.69958,0 10.32,-4.62042 10.32,-10.32c0,-5.69958 -4.62042,-10.32 -10.32,-10.32zM41.13219,99.71969c-1.27749,0.04213 -2.42632,0.78902 -2.98323,1.9395c-0.55691,1.15048 -0.43009,2.51487 0.32932,3.543c0,0 17.99505,25.51781 47.52172,25.51781c29.52667,0 47.52172,-25.51781 47.52172,-25.51781c1.10578,-1.54735 0.74781,-3.69813 -0.79953,-4.8039c-1.54735,-1.10578 -3.69813,-0.74781 -4.8039,0.79953c0,0 -16.40495,22.64219 -41.91828,22.64219c-25.51333,0 -41.91828,-22.64219 -41.91828,-22.64219c-0.6674,-0.96274 -1.77882,-1.51971 -2.94953,-1.47813z">
                                    </path>
                                </g>
                            </g>
                        </svg><br>
                        <p class="cta-text"> Pleasantly Surprised</p>
                    </div>
                    <div class="col-lg-2 col-md-6 text-center text-lg-left">
                        <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="45" height="45" viewBox="0 0 172 172" style=" fill:#000000;">
                            <g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal">
                                <path d="M0,172v-172h172v172z" fill="none"></path>
                                <g fill="#ffffff">
                                    <g id="surface1">
                                        <path d="M89.1175,0c-0.5375,0.05375 -1.04812,0.24188 -1.505,0.5375c0,0 -21.74187,14.09594 -43.43,33.2175c-10.84406,9.55406 -21.64781,20.35781 -29.885,31.4975c-8.23719,11.13969 -14.06906,22.64219 -13.975,33.8625c0,5.38844 2.24406,9.675 5.2675,12.5775c3.02344,2.9025 6.70531,4.54188 10.105,6.02c3.39969,1.47813 6.53063,2.82188 8.4925,4.1925c1.96188,1.37063 2.6875,2.19031 2.6875,4.3c0,0.81969 -0.79281,2.60688 -2.4725,4.73c-1.67969,2.12313 -4.03125,4.56875 -6.5575,7.2025c-5.06594,5.28094 -10.965,11.42188 -10.965,19.4575c0,3.78938 1.54531,7.00094 3.7625,9.1375c2.21719,2.13656 4.99875,3.23844 7.525,3.9775c5.06594,1.49156 9.7825,1.29 9.7825,1.29c1.89469,-0.05375 3.38625,-1.65281 3.3325,-3.5475c-0.05375,-1.89469 -1.65281,-3.38625 -3.5475,-3.3325c0,0 -3.92375,0.12094 -7.6325,-0.9675c-1.85437,-0.55094 -3.5475,-1.43781 -4.6225,-2.4725c-1.075,-1.03469 -1.72,-2.01562 -1.72,-4.085c0,-4.34031 4.11188,-9.59437 9.03,-14.7275c2.45906,-2.56656 5.02563,-5.11969 7.095,-7.74c2.06938,-2.62031 3.87,-5.44219 3.87,-8.9225c0,-4.43437 -2.6875,-7.88781 -5.6975,-9.9975c-3.01,-2.10969 -6.45,-3.3325 -9.675,-4.73c-3.225,-1.3975 -6.1275,-2.98312 -8.0625,-4.8375c-1.935,-1.85437 -3.1175,-3.80281 -3.1175,-7.525c0,-0.04031 0,-0.06719 0,-0.1075c-0.08062,-8.73437 4.79719,-19.14844 12.5775,-29.67c7.78031,-10.52156 18.40938,-21.05656 29.025,-30.4225c21.23125,-18.71844 42.4625,-32.5725 42.4625,-32.5725c1.35719,-0.84656 1.94844,-2.51281 1.43781,-4.01781c-0.51063,-1.51844 -2.00219,-2.4725 -3.58781,-2.32469zM157.9175,44.72c-3.61469,0 -7.24281,1.33031 -9.9975,4.085l-2.365,2.4725l19.8875,19.8875l2.4725,-2.365c5.50938,-5.50937 5.50938,-14.48562 0,-19.995c-2.75469,-2.75469 -6.38281,-4.085 -9.9975,-4.085zM141.3625,55.3625l-91.805,92.235c-0.48375,0.47031 -0.81969,1.06156 -0.9675,1.72l-3.7625,18.5975c-0.18812,1.10188 0.16125,2.23063 0.95406,3.02344c0.79281,0.79281 1.92156,1.14219 3.02344,0.95406l18.5975,-3.7625c0.65844,-0.14781 1.24969,-0.48375 1.72,-0.9675l92.235,-91.805l-4.8375,-4.8375l-91.16,90.8375l-9.9975,-9.9975l90.8375,-91.16z">
                                        </path>
                                    </g>
                                </g>
                            </g>
                        </svg><br>
                        <p class="cta-text">Sign The Contract</p>
                    </div>
                </div>

            </div>
        </section>


        <!-- #about -->

        <!--==========================
      Portfolio Section
     ============================-->

        <section id="portfolio" class="section-bg">
            <div class="container">

                <header class="section-header">
                    <h3 class="section-title">Our Projects</h3>
                </header>
                <div class="row">
                    <div class="col-lg-12">
                        <ul id="portfolio-flters">
                            <li data-filter="*" class="filter-active">All</li>
                            <li data-filter=".filter-app">App</li>
                            <li data-filter=".filter-web">Web</li>
                        </ul>
                    </div>
                </div>
                <div class="row portfolio-container">
                    <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                        <div class="portfolio-wrap">
                            <img src="img/portfolio/dwell.png" class="img-fluid" alt="">
                            <div class="portfolio-info">
                                <h4><a href="JavaScript:Void(0);">Dwell Food</a></h4>
                                <p>Application</p>
                                <div>
                                    <a href="img/portfolio/dwell.png" data-lightbox="portfolio" data-title="Dwell Food" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                                    <a href="portfolio.php" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 portfolio-item filter-web">
                        <div class="portfolio-wrap">
                            <img src="img/portfolio/event.png" class="img-fluid" alt="">
                            <div class="portfolio-info">
                                <h4><a href="JavaScript:Void(0);">Event Mahotsav</a></h4>
                                <p>Web</p>
                                <div>
                                    <a href="img/portfolio/event.png" data-lightbox="portfolio" data-title="Event Mahotsav" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                                    <a rel="nofollow" href="JavaScript:Void(0);" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 portfolio-item filter-web">
                        <div class="portfolio-wrap">
                            <img src="img/portfolio/shrisai.png" class="img-fluid" alt="">
                            <div class="portfolio-info">
                                <h4><a href="JavaScript:Void(0);">ShriSai Enterprises</a></h4>
                                <p>Web</p>
                                <div>
                                    <a href="img/portfolio/shrisai.png" data-lightbox="portfolio" data-title="ShriSai Enterprises" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                                    <a rel="nofollow" href="JavaScript:Void(0);" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>

            </div>
        </section>

        <!--==========================
      Clients Section
        ============================-->

        <section id="testimonials" style="background-image:url(" img/review.jpg"); -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover;">
            <div class="container" style="background: rgba(0, 0, 0, 0.8);">
                </br>
                <header class="section-header">
                    <h3 style="color:#b5e0fe;">Testimonials</h3>
                </header>

                <div class="row justify-content-center">
                    <div class="col-lg-8">

                        <div class="owl-carousel testimonials-carousel wow fadeInUp">



                            <div class="testimonial-item" class="text-white">

                                <h3 class="text-white">Pradeep</h3>
                                <h4>March 2018 </h4>
                                <p class="text-white">
                                    Presently It Solutions was friendly and with consistent communication. They always met
                                    deadlines and were
                                    helpful with both
                                    web and graphic design. Presently It Solutions did a good job with our proof of concept
                                    and I would use
                                    them again!.
                                </p>
                            </div>
                            <div class="testimonial-item text-white">

                                <h3 class="text-white">Karen </h3>
                                <h4>DEC 10th 2018 </h4>
                                <p>
                                    Customer support is great. Layout is nice and clear. Great company to work with.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        </main>



        <?php include("part/footer.php"); ?>
        <!-- #footer -->

</body>

</html>