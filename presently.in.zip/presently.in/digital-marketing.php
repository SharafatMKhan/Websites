<!DOCTYPE html>
<html lang="en">


<head>
     <title>Digital Marketing | Presently Solutions | Software Development Company</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
        content="At Presently, we make BRANDS AND BUSINESSES achieve exponential success by effectively leveraging the combined power of Mobile, Social Media, Web, Videos and Data Analytics to excite and engage consumers."
        property="description">
    <meta name="author" content="Presently Solutions" property="author">
    <meta name="canonical" content="https://presently.in/digital-marketing.php" property="canonical">
    <meta name="robots" content="Index, follow">
    <meta name="og:title" content="Presently Solutions:Top IT Company " property="og:title">
    <meta name="og:description" content="Presently Solutions software development company in Bhopal,India"
        property="og:description">
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <meta name="keywords" content="Leading It company in Bhopal,Customized software service,Web design and development,
         mobile app development, Software solutions,app developers, web application and development, leading software solution provider in Bhopal,India,Dynamic Websites,Bhopal web development, Bhopal mobile app development, Bhopal app developer, Bhopal web design, Bhopal logo design,
         US based IT company in Thrissur,Custom developed websites,WebSite Hosting,software support and solutions in Bhopal,India,
         Professionals in software development, Best software company in Central India " property="keywords">
    <meta name="keyphrase"
        content="Best Software company in thrissur, Top IT company in Bhopal,software solutions,
                Website design and development company Bhopal,IOS and Andoird application development company Thrissur" />
    <meta name="topic" content="Software" />
    <meta name="subject" content="Digital Marketing" />
    <meta name="classification" content="Software,Website development,Leading,Best,Top Company" />
    <meta name="rating" content="general">
    <meta name="audience" content="all" />
    <meta property="og:type" content="Software Company" />
    <meta property="og:url" content="https://www.facebook.com/presentlysolutions/" />
    <meta property="og:site_name" content="www.Presently.in" />
    <meta name="og:image" content="img/companyculture.png" />
    <meta name="og:email" content=" info@presently.in" />
    <meta name="og:phone_number" content="+919993357325" />
    <meta itemprop="name" content="Software Company, Bhopal" />
    <meta itemprop="description"
        content="Presently Soultions is the top web designing and web development in Bhopal who offers attractive website designs with creative web designers in Bhopal" />
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <link rel="canonical" href="index.php" />
    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700"
        rel="stylesheet">
    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">

    <script src='../www.google.com/recaptcha/api.js'></script>

</head>

<body>
    <!--==========================
  Header
  ============================-->
<?php include("part/header.php"); ?>
<!-- #header -->
	

    <main id="main">

	 <section  class="inner-banner text-center" style="background-image:url('img/digital.png')">
            <div class="container">
                <div class="box" >
                    <h3 id="headtop">
                     Digital Marketing</h3>
                </div>
            </div>
</section>

        <!--==========================
      About Us Section
    ============================-->
        <section id="about">

            <div class="container">
                <div class="row"> 

                    <div class="col-lg-12 col-md-12">
                        <div class="about-content">
                            <h2>Digital Marketing</h2>
                            <p style="line-height: 2;">Presently Digital Marketing agency is a full service digital marketing company in Bhopal, Madhya Pradesh . We provide complete digital marketing services to our customers , in India and abroad. Growing Your Business is all that matters for us. Over the past decade, Presently Digital marketing agency has an experienced team of digital marketing experts who work to promote your business using various Digital marketing tools and research.</p>

                        <p style="line-height: 2;">
At Presently tech, We provide various digital marketing services like Search engine optimization, Social media marketing, Search Engine Marketing, Email marketing, Motion videos and illustrations and online reputation management etc.</p>
                        </div>
                        </div>
                        </div>
						
					 <div class="row"> 
	
                    <div class="min-ht340 col-lg-4 col-md-4 col-sm-6 text-center digital-details min-height370 wow fadeInLeft" data-wow-delay=".6s">
           
                <h5 style="font-weight: 800;">SOCIAL MEDIA MARKETING</h5>
            <p style="line-height: 2;">Presently Digital marketing company provides Social media marketing or advertising services for our customers which helps them to reach their business to more people. Our solutions across multiple social media websites like Instagram, Pinterest, Whatsapp, Twitter, Facebook etc. Helps you to engage with target users. </p>    
            </div>
            <div class="min-ht340 col-lg-4 col-md-4 col-sm-6 text-center digital-details min-height370 wow bounceInUp" data-wow-delay="1s">
                            
                <h5 style="font-weight: 800;">SEARCH ENGINE OPTIMIZATION</h5>
            <p style="line-height: 2;">Presently digital marketing and Search engine optimization (SEO) company offers both on-page SEO and off-page SEO services for clients. In major search engines like google, users are more likely to choose one of the top 10 suggestions in the search engine results page. Presently helps you to Show your website address in the first page of the list.</p>    
            </div>
                        <div class="min-ht340 col-lg-4 col-md-4 col-sm-6 text-center digital-details min-height370 wow fadeInUp" data-wow-delay=".6s">
           
                <h5 style="font-weight: 800;">EMAIL & SMS MARKETING</h5>
            <p style="line-height: 2;">Presently digital marketing and Search engine optimization (SEO) company offers email marketing services for clients. Email marketing is important for building relationships with customers, and even past customers because it is a wat interact directly with them.</p>    
            </div>
             
              
            </div>

        </section><!-- #about -->

       
     
  </main>
    <!--==========================
    Footer
  ============================-->
  <?php include("part/footer.php"); ?>
  <!-- #footer -->

    

</body>


</html>