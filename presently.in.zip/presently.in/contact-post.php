			           <?php  
							include("include/connect.php");
							
					if(isset($_POST['saves'])){
							date_default_timezone_set('Asia/Kolkata');

							$sender_name = $_POST['name'];
							$sender_email = $_POST['email'];
							$sender_phone = $_POST['phone'];
							$sender_position = $_POST['position'];
							$sender_comments = $_POST['comments'];
							
							$image_name=$_FILES['image']['name'];
							$image_type=$_FILES['image']['type'];
							$image_size=$_FILES['image']['size'];
							$image_tmp=$_FILES['image']['tmp_name'];

							$sender_date = date("F j, Y");
					move_uploaded_file($image_tmp,"file/$image_name");
				$query = "insert into shrisairesume (name,email,phone,message,date,subject,resume) values ('$sender_name','$sender_email','$sender_phone','$sender_comments','$sender_date','$sender_position','$image_name')";

				if(mysqli_query($connect,$query))
				{
				echo "<script>window.open('career.php?updated=insert successfully..','_self')</script>";

				}	
											}
											
											
			if(isset($_POST['submit'])){
			date_default_timezone_set('Asia/Kolkata');

			$sender_name = $_POST['name'];
			$sender_email = $_POST['email'];
			$sender_phone = $_POST['phone'];
			$sender_position = $_POST['position'];
			$sender_city = $_POST['city'];
			$sender_message = $_POST['message'];
		

			$sender_date = date("F j, Y");
	
					$query1 = "insert into presentlyone (name,email,phone,position,city,message,date) values ('$sender_name','$sender_email','$sender_phone','$sender_position','$sender_city','$sender_message','$sender_date')";

					if(mysqli_query($connect,$query1))
					{
					echo "<script>window.open('index.php?updated=insert successfully..','_self')</script>";

							}		}									
				
				
				if(isset($_POST['submits'])){
			date_default_timezone_set('Asia/Kolkata');

			$sender_name = $_POST['name'];
			$sender_email = $_POST['email'];
			$sender_subject = $_POST['subject'];
			
			$sender_message = $_POST['message'];
		

			$sender_date = date("F j, Y");
	
					$query1 = "insert into presentlytwo (name,email,subject,message,date) values ('$sender_name','$sender_email','$sender_subject','$sender_message','$sender_date')";

					if(mysqli_query($connect,$query1))
					{
					echo "<script>window.open('index.php?updated=insert successfully..','_self')</script>";

							}		}									
				
						 ?>