<?php

$connect=mysqli_connect("localhost","vijaythegreats","xpxa3QS8qjZG","vijaytdb");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>