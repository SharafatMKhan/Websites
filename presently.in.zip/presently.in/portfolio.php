<!DOCTYPE html>
<html lang="en">


<head>
        <title>Portfolio | Presently Solutions | Software Development Company</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
        content="We are US based  software company in India that offers abundant software services and  solutions to minimise work and maximise the success of your business."
        property="description">
    <meta name="author" content="Presently Solutions" property="author">
    <meta name="canonical" content="https://presently.in/portfolio.php" property="canonical">
    <meta name="robots" content="Index, follow">
    <meta name="og:title" content="Presently Solutions:Top IT Company " property="og:title">
    <meta name="og:description" content="Presently Solutions software development company in Bhopal,India"
        property="og:description">
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <meta name="keywords" content="Leading It company in Bhopal,Customized software service,Web design and development,
         mobile app development, Software solutions,app developers, web application and development, leading software solution provider in Bhopal,India,Dynamic Websites,Bhopal web development, Bhopal mobile app development, Bhopal app developer, Bhopal web design, Bhopal logo design,
         US based IT company in Thrissur,Custom developed websites,WebSite Hosting,software support and solutions in Bhopal,India,
         Professionals in software development, Best software company in Central India " property="keywords">
    <meta name="keyphrase"
        content="Best Software company in thrissur, Top IT company in Bhopal,software solutions,
                Website design and development company Bhopal,IOS and Andoird application development company Thrissur" />
    <meta name="topic" content="Software" />
    <meta name="subject" content="Portfolio" />
    <meta name="classification" content="Software,Website development,Leading,Best,Top Company" />
    <meta name="rating" content="general">
    <meta name="audience" content="all" />
    <meta property="og:type" content="Software Company" />
    <meta property="og:url" content="https://www.facebook.com/presentlysolutions/" />
    <meta property="og:site_name" content="www.Presently.in" />
    <meta name="og:image" content="img/companyculture.png" />
    <meta name="og:email" content=" info@presently.in" />
    <meta name="og:phone_number" content="+919993357325" />
    <meta itemprop="name" content="Software Company, Bhopal" />
    <meta itemprop="description"
        content="Presently Soultions is the top web designing and web development in Bhopal who offers attractive website designs with creative web designers in Bhopal" />
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <link rel="canonical" href="index.php" />
    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700"
        rel="stylesheet">
    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">

    
	
</head>

<body>
    <!--==========================
  Header
  ============================-->
<?php include("part/header.php"); ?>
<!-- #header -->
	

    <main id="main">
	
	 <section  class="inner-banner text-center" style="background-image:url('img/portfoliobanner.png')">
            <div class="container">
                <div class="box">
                    <h3>
                     Portfolio</h3>
                </div>
            </div>
</section>

        <!--==========================
      Portfolio Section
    ============================-->
        <section id="portfolio" class="section-bg">
            <div class="container">

               
                <div class="row">
                    <div class="col-lg-12">
                        <ul id="portfolio-flters">
                            <li data-filter="*" class="filter-active">All</li>
                            <li data-filter=".filter-app">App</li>
                            <li data-filter=".filter-web">Web</li>
                        </ul>
                    </div>
                </div>
                <div class="row portfolio-container">
				
				
				<div class="col-lg-4 col-md-6 portfolio-item filter-web">
                        <div class="portfolio-wrap">
                            <img src="img/portfolio/shrisai.png" class="img-fluid" alt="">
                            <div class="portfolio-info">
                                <h4><a href="JavaScript:Void(0);">ShriSai Enterprises</a></h4>
                                <p>Web</p>
                                <div>
                                    <a href="img/portfolio/shrisai.png" data-lightbox="portfolio"
                                        data-title="ShriSai Enterprises" class="link-preview" title="Preview"><i
                                            class="ion ion-eye"></i></a>
                                    <a rel="nofollow" href="JavaScript:Void(0);" class="link-details" title="More Details"><i
                                            class="ion ion-android-open"></i></a>
                                </div>
                            </div>
                        </div>
                    </div><div class="col-lg-4 col-md-6 portfolio-item filter-web">
                        <div class="portfolio-wrap">
                            <img src="img/portfolio/event.png" class="img-fluid" alt="">
                            <div class="portfolio-info">
                                <h4><a href="JavaScript:Void(0);">Event Mahotsav</a></h4>
                                <p>Web</p>
                                <div>
                                    <a href="img/portfolio/event.png" data-lightbox="portfolio"
                                        data-title="Event Mahotsav" class="link-preview" title="Preview"><i
                                            class="ion ion-eye"></i></a>
                                    <a rel="nofollow" href="JavaScript:Void(0);" class="link-details" title="More Details"><i
                                            class="ion ion-android-open"></i></a>
                                </div>
                            </div>
                        </div>
                    </div><div class="col-lg-4 col-md-6 portfolio-item filter-web">
                        <div class="portfolio-wrap">
                            <img src="img/portfolio/goldencarry.png" class="img-fluid" alt="">
                            <div class="portfolio-info">
                                <h4><a href="JavaScript:Void(0);">Golden Carry School</a></h4>
                                <p>Web</p>
                                <div>
                                    <a href="img/portfolio/goldencarry.png" data-lightbox="portfolio"
                                        data-title="Golden Carry School" class="link-preview" title="Preview"><i
                                            class="ion ion-eye"></i></a>
                                    <a rel="nofollow" href="JavaScript:Void(0);" class="link-details" title="More Details"><i
                                            class="ion ion-android-open"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
					
					
					
					<div class="col-lg-4 col-md-6 portfolio-item filter-web">
                        <div class="portfolio-wrap">
                            <img src="img/portfolio/san.png" class="img-fluid" alt="">
                            <div class="portfolio-info">
                                <h4><a href="JavaScript:Void(0);">San Builders</a></h4>
                                <p>Web</p>
                                <div>
                                    <a href="img/portfolio/san.png" data-lightbox="portfolio"
                                        data-title="San Builders" class="link-preview" title="Preview"><i
                                            class="ion ion-eye"></i></a>
                                    <a rel="nofollow" href="JavaScript:Void(0);" class="link-details" title="More Details"><i
                                            class="ion ion-android-open"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="col-lg-4 col-md-6 portfolio-item filter-web">
                        <div class="portfolio-wrap">
                            <img src="img/portfolio/shineup.png" class="img-fluid" alt="">
                            <div class="portfolio-info">
                                <h4><a href="JavaScript:Void(0);">Shineup Creation</a></h4>
                                <p>Web</p>
                                <div>
                                    <a href="img/portfolio/shineup.png" data-lightbox="portfolio"
                                        data-title="Shineup Creation" class="link-preview" title="Preview"><i
                                            class="ion ion-eye"></i></a>
                                    <a rel="nofollow" href="JavaScript:Void(0);" class="link-details" title="More Details"><i
                                            class="ion ion-android-open"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="col-lg-4 col-md-6 portfolio-item filter-web">
                        <div class="portfolio-wrap">
                            <img src="img/portfolio/earthnature.png" class="img-fluid" alt="">
                            <div class="portfolio-info">
                                <h4><a href="JavaScript:Void(0);">Earth Natures</a></h4>
                                <p>Web</p>
                                <div>
                                    <a href="img/portfolio/earthnature.png" data-lightbox="portfolio"
                                        data-title="Earth Natures" class="link-preview" title="Preview"><i
                                            class="ion ion-eye"></i></a>
                                    <a rel="nofollow" href="JavaScript:Void(0);" class="link-details" title="More Details"><i
                                            class="ion ion-android-open"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
				
				
				
				
				
				
				
                    <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                        <div class="portfolio-wrap">
                            <img src="img/portfolio/dwell.png" class="img-fluid" alt="">
                            <div class="portfolio-info">
                                <h4><a href="JavaScript:Void(0);">Dwell Food</a></h4>
                                <p>Application</p>
                                <div>
                                    <a href="img/portfolio/dwell.png" data-lightbox="portfolio"
                                        data-title="Dwell Food" class="link-preview" title="Preview"><i
                                            class="ion ion-eye"></i></a>
                                    <a rel="nofollow" href="JavaScript:Void(0);" class="link-details" title="More Details"><i
                                            class="ion ion-android-open"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 portfolio-item filter-web" data-wow-delay="0.1s">
                        <div class="portfolio-wrap">
                            <img src="img/portfolio/teacherjii.png" class="img-fluid" alt="">
                            <div class="portfolio-info">
                                <h4><a  href="JavaScript:Void(0);">Teacher Ji</a></h4>
                                <p>Web</p>
                                <div>
                                    <a href="img/portfolio/teacherjii.png" class="link-preview"
                                        data-lightbox="portfolio" data-title="Teacher ji" title="Preview"><i
                                            class="ion ion-eye"></i></a>
                                    <a rel="nofollow"  href="JavaScript:Void(0);" class="link-details"
                                        title="More Details"><i class="ion ion-android-open"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-md-6 portfolio-item filter-web" data-wow-delay="0.1s">
                        <div class="portfolio-wrap">
                            <img src="img/portfolio/ambitionschool.png" class="img-fluid" alt="">
                            <div class="portfolio-info">
                                <h4><a rel="nofollow" href="JavaScript:Void(0);">Ambition Public School </a></h4>
                                <p>Web</p>
                                <div>
                                    <a href="img/portfolio/ambitionschool.png" class="link-preview" data-lightbox="portfolio"
                                        data-title="Ambition Public School" title="Preview"><i class="ion ion-eye"></i></a>
                                    <a href="JavaScript:Void(0);" class="link-details" title="More Details"><i
                                            class="ion ion-android-open"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                  
                </div>

            </div>
        </section><!-- #portfolio -->


       
     <!--==========================
      Clients Section
    ============================ -->
        <section id="clients" class="wow fadeInUp">
            <div class="container">

                <header class="section-header">
                    <h3>Our Partners</h3>
                </header>

                <div class="owl-carousel clients-carousel">
                    <img src="img/partners/strive.png" alt="">
                    <img src="img/partners/playitsafe.png" style="padding:20px 0;" alt="">
                    <img src="img/partners/croveland.png" alt="">
                    <img src="img/partners/doyelstown.png" style="padding:40px 0;width:100%" alt="">
                    <img src="img/partners/gea.png" style="width:50%;padding-top:20px" alt="">
                    <img src="img/partners/gulfport.png" style="padding:10px 0;width:70%" alt="">
                    <img src="img/partners/hager.png" style="padding:20px 0;width:100%" alt="">
                    <img src="img/partners/nrpa.png" style="width:60%" alt="">
                    <img src="img/partners/dm.png" style="width:60%;padding:10px;" alt="">
                    <img src="img/partners/corallvilla.png" style="padding:20px 0px;width:90%" alt="">
                    <img src="img/partners/village.png" style="padding:40px 0px;width:90%" alt="">
                    <img src="img/partners/carmelclay.png" alt="">
                    <img src="img/partners/cca.png" style="width:60%;padding:10px 0" alt="">
                    <img src="img/partners/hudson.png" style="padding:0px 0px;width:50%" alt="">
                    <img src="img/partners/waukee.png" alt="">
                    <img src="img/partners/townof.png" alt="">
                    <img src="img/partners/TBL_ventures.png" style="padding:0px 0px;width:60%" alt="">
                    <img src="img/partners/Reimer_systems.jpg" alt="">
                </div>

            </div>
        </section><!-- #clients -->

  </main>
    <!--==========================
    Footer
  ============================-->
  <?php include("part/footer.php"); ?>
  <!-- #footer -->

  

</body>


</html>