
	
			
					
	  <section id="why-us" class="wow fadeIn" style="background-color:#1a2940; ">
  <div class="container">

             <a class="whatspp" href="https://api.whatsapp.com/send?phone=919993357325%20&amp;text=Hello%20Sir,%20I%20am%20interested%20in%20your%20Web%20Services.%20Please%20get%20in%20touch">
    <img src="img/whatd2.png">
</a>
                <div class="row counters" >
                    <div class="col-lg-3 col-6 text-center" >
                        <span data-toggle="counter-up" style="color:white;">35</span>
                        <p >Happy Clients</p>
                    </div>
                    <div class="col-lg-3 col-6 text-center">
                        <span data-toggle="counter-up" style="color:white;">50</span>
                        <p>Projects</p>
                    </div>
                    <div class="col-lg-3 col-6 text-center">
                        <span  style="color:white;">24/7</span>
                        <p>Hours Of Support</p>
                    </div>
                    <div class="col-lg-3 col-6 text-center">
                        <span data-toggle="counter-up" style="color:white;">12</span>
                        <p>Hard Workers</p>
                    </div>
                </div>
            </div>
			 </section>
 <footer id="footer" class="section-bg">
        <div class="footer-top">
            <div class="container">

                <div class="row">

                    <div class="col-lg-6">

                        <div class="row">

                            <div class="col-sm-6">

                                <div class="footer-info">
                                    <h3>Presently SOLUTIONS</h3>
                                    <p>Founded in 2018 in Bhopal, India, Presently It started as a web development
                                        company and quickly
                                        moved into the mobile development market. today we are a full-cycle service
                                        provider with a
                                        dedicated development team with expertise in web & mobile development, project
                                        management, digital
                                        design, technical support and quality assurance.<a href="#about">more..</a> </p>
                                </div>

                                <!-- <div class="footer-newsletter">
                    <h4>Our Newsletter</h4>
                    <p>Tamen quem nulla quae legam multos aute sint culpa legam noster magna veniam enim veniam illum dolore legam minim quorum culpa amet magna export quem.</p>
                    <form action="" method="post">
                      <input type="email" name="email"><input type="submit"  value="Subscribe">
                    </form>
                  </div> -->

                            </div>

                            <div class="col-sm-6">
                                <div class="footer-links">
                                    <h4>Useful Links</h4>
                                    <ul>
                                        <li><a href="#intro">Home</a></li>
                                        <li><a href="#about">About us</a></li>
                                        <li><a href="#services">Services</a></li>
                                        <li><a href="img/PresentlySolutionTermsofUse.pdf">Terms & Conditions</a></li>
                                        <li><a href="img/PresentlySolutionsPrivacyPolicy.pdf">Privacy policy</a></li>
                                    </ul>
                                </div>

                                <div class="footer-links">
                                    <h4>Contact Us</h4>
                                    <p><!--
                                        Plot No. B229 Indra Nagar ,<br>
                                        Om Sai Ram Multicomplex, Mandideep, Bhopal(M.P) 462046 <br>-->
										
                                        <strong>Email:</strong>
                                        <a href="mailto:info@presently.in">info@presently.in</a>
                                    </p>
                                </div>

                                <div class="social-links">
                                    <a href="https://twitter.com/presentlysolutions" title="Presently Solutions" target="_blank" class="twitter"><i
                                            class="fa fa-twitter"></i></a>
                                    <a href="https://www.facebook.com/presentlysolutions/" title="Presently Solutions" target="_blank" class="facebook"><i
                                            class="fa fa-facebook"></i></a>
                                    <a href="https://www.linkedin.com/company/presentlysolutions/" title="Presently Solutions" target="_blank"
                                        class="linkedin"><i class="fa fa-linkedin"></i></a>
                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="col-lg-6">

                        <div class="form">

                            <h4>KEEP IN TOUCH</h4>
                            <p> We'd <span class="love">&#9825;</span> to help! &nbsp;&nbsp; If you want something else
                                there, should
                                be focused on their project or area of interest, such us, Please share with us your idea
                                or project.</p>
                            <form
                                action="contact-post.php"
                                method="post" role="form" class="contactForm">
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control" id="name"
                                        placeholder="Your Name" data-rule="minlen:4"
                                        data-msg="Please enter at least 4 chars" />
                                    <div class="validation"></div>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" name="email" id="email"
                                        placeholder="Your Email" data-rule="email"
                                        data-msg="Please enter a valid email" />
                                    <div class="validation"></div>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="subject" id="subject"
                                        placeholder="Subject" data-rule="minlen:4"
                                        data-msg="Please enter at least 8 chars of subject" />
                                    <div class="validation"></div>
                                </div>
                                <div class="form-group">
                                    <textarea class="form-control" name="message" rows="5" data-rule="required"
                                        data-msg="Please write something for us" placeholder="Message"></textarea>
                                    <div class="validation"></div>
                                </div>

                                <div id="sendmessage">Your message has been sent. Thank you!</div>
                                <div id="errormessage"></div>

                                <div class="text-center"><button type="submit" name="submits" title="Send Message">Send
                                        Message</button></div>
                            </form>
                        </div>

                    </div>



                </div>

            </div>
        </div>

        <div class="container">
            <div class="copyright">
                &copy; Copyright <strong>Presently Solutions</strong>. All Rights Reserved
            </div>
            <div class="credits">
                Designed by <a href="https://www.presently.in">Presently Solutions</a>
            </div>
        </div>
    </footer>
	  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
    <!-- Uncomment below i you want to use a preloader -->
    <!-- <div id="preloader"></div> -->

    <!-- JavaScript Libraries -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/jquery/jquery-migrate.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/mobile-nav/mobile-nav.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/isotope/isotope.pkgd.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>
    <!-- Contact Form JavaScript File -->
    <script src="contactform/contactform.js"></script>

    <!-- Template Main Javascript File -->
    <script src="js/main.js"></script>

	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-188680746-1">
</script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-188680746-1');
</script>


<!-- Load Facebook SDK for JavaScript -->
      <div id="fb-root"></div>
      <script>
        window.fbAsyncInit = function() {
          FB.init({
            xfbml            : true,
            version          : 'v9.0'
          });
        };

        (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));</script>

      <!-- Your Chat Plugin code -->
      <div class="fb-customerchat"
        attribution="setup_tool"
        page_id="107388294316554">
      </div>


    <script>
        function initMap() {
            var uluru = {
                lat: 41.6645583,
                lng: -93.6253819
            };
            var map = new google.maps.Map(document.getElementById('map'), {
                zoom: 5,
                center: uluru
            });
            var marker = new google.maps.Marker({
                position: uluru,
                map: map
            });
        }
        (function titleScroller(text) {
            document.title = text;
            setTimeout(function () {
                titleScroller(text.substr(1) + text.substr(0, 1));
            }, 500);
        }(" Presently It Solutions | Software Development Company |"));
        window.onscroll = function () {
            myFunction()
        };
        // var navbar = document.getElementById("navmenu");
        // var sticky = navbar.offsetTop;

        // function myFunction() {
        // 	if (window.pageYOffset >= sticky) {
        // 		navbar.classList.add("sticky")
        // 	} else {
        // 		navbar.classList.remove("sticky");
        // 	}
        // }
        function validateForm() {
            var nm = document.getElementById("referrerName").value;
            var em = document.getElementById("referrerEmail").value;
            var atpos = em.indexOf("@");
            var dotpos = em.lastIndexOf(".");
            var refnm = document.getElementById("refName").value;
            var refem = document.getElementById("refEmail").value;
            var atposi = refem.indexOf("@");
            var dotposi = refem.lastIndexOf(".");
            var refph = document.getElementById("phone").value;
            var refmsg = document.getElementById("refMessage").value;
            if (nm == "") {
                document.getElementById("rName").innerHTML = "* Enter Your Name";
                return false;
            } else if (em == "") {
                document.getElementById("rName").innerHTML = "";
                document.getElementById("rEmail").innerHTML = "* Enter Your Email";
                return false;
            } else if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= em.length) {
                var msg = "Please enter a valid email address.";
                document.getElementById('rEmail').innerHTML = msg;
                return false;
            } else if (refnm == "") {
                document.getElementById("rName").innerHTML = "";
                document.getElementById("rEmail").innerHTML = "";
                document.getElementById("reName").innerHTML = "* Enter Referrence Name";
                return false;
            } else if (refem == "") {
                document.getElementById("rName").innerHTML = "";
                document.getElementById("rEmail").innerHTML = "";
                document.getElementById("reName").innerHTML = "";
                document.getElementById("reEmail").innerHTML = "* Enter Email";
                return false;
            } else if (atposi < 1 || dotposi < atposi + 2 || dotposi + 2 >= refem.length) {
                var msg = "Please enter a valid email address.";
                document.getElementById('reEmail').innerHTML = msg;
                return false;
            } else if (refph == "") {
                document.getElementById("rName").innerHTML = "";
                document.getElementById("rEmail").innerHTML = "";
                document.getElementById("reName").innerHTML = "";
                document.getElementById("reEmail").innerHTML = "";
                document.getElementById("reNumber").innerHTML = "* Enter Phone Number";
                return false;
            } else if (isNaN(refph)) {
                document.getElementById("rName").innerHTML = "";
                document.getElementById("rEmail").innerHTML = "";
                document.getElementById("reName").innerHTML = "";
                document.getElementById("reNumber").innerHTML = "* Enter Valid Phone Number";
                return false;
            } else if (refmsg == "") {
                document.getElementById("rName").innerHTML = "";
                document.getElementById("rEmail").innerHTML = "";
                document.getElementById("reName").innerHTML = "";
                document.getElementById("reNumber").innerHTML = "";
                document.getElementById("reMsg").innerHTML = "* Enter Your Message";
                return false;
            } else
                alert("Submitted Successfully.");
            return true;
            //  window.location.href = "https://www.parkzapp.com/webservices/zamorinsWebsite/Presently It.in/src/referral.php";   
        }


        function validateRequest() {
            // var nm = document.getElementById("referrerName").value;
            // var em = document.getElementById("referrerEmail").value;
            // var atpos = em.indexOf("@");
            // var dotpos = em.lastIndexOf(".");
            var refnm = document.getElementById("refName").value;
            var refem = document.getElementById("refEmail").value;
            var atposi = refem.indexOf("@");
            var dotposi = refem.lastIndexOf(".");
            var refph = document.getElementById("phone").value;
            var refmsg = document.getElementById("refMessage").value;
            // if (nm == "") {
            //   document.getElementById("rName").innerHTML = "* Enter Your Name";
            //   return false;
            // } else if (em == "") {
            //   document.getElementById("rName").innerHTML = "";
            //   document.getElementById("rEmail").innerHTML = "* Enter Your Email";
            //   return false;
            // } else if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= em.length) {
            //   var msg = "Please enter a valid email address.";
            //   document.getElementById('rEmail').innerHTML = msg;
            //   return false;
            // } else
            if (refnm == "") {
                document.getElementById("rName").innerHTML = "";
                document.getElementById("rEmail").innerHTML = "";
                document.getElementById("reName").innerHTML = "* Enter Name";
                return false;
            } else if (refem == "") {
                document.getElementById("rName").innerHTML = "";
                document.getElementById("rEmail").innerHTML = "";
                document.getElementById("reName").innerHTML = "";
                document.getElementById("reEmail").innerHTML = "* Enter Email";
                return false;
            } else if (atposi < 1 || dotposi < atposi + 2 || dotposi + 2 >= refem.length) {
                var msg = "Please enter a valid email address.";
                document.getElementById('reEmail').innerHTML = msg;
                return false;
            } else if (refph == "") {
                document.getElementById("rName").innerHTML = "";
                document.getElementById("rEmail").innerHTML = "";
                document.getElementById("reName").innerHTML = "";
                document.getElementById("reEmail").innerHTML = "";
                document.getElementById("reNumber").innerHTML = "* Enter Phone Number";
                return false;
            } else if (isNaN(refph)) {
                document.getElementById("rName").innerHTML = "";
                document.getElementById("rEmail").innerHTML = "";
                document.getElementById("reName").innerHTML = "";
                document.getElementById("reNumber").innerHTML = "* Enter Valid Phone Number";
                return false;
            } else if (refmsg == "") {
                document.getElementById("rName").innerHTML = "";
                document.getElementById("rEmail").innerHTML = "";
                document.getElementById("reName").innerHTML = "";
                document.getElementById("reNumber").innerHTML = "";
                document.getElementById("reMsg").innerHTML = "* Enter Your Message";
                return false;
            } else
                alert("Submitted Successfully.");
            return true;
            //  window.location.href = "https://www.parkzapp.com/webservices/zamorinsWebsite/Presently It.in/src/referral.php";   
        }
    //	REDIRECTS TO HTTPS
    //  if (location.protocol == 'http:') location.href = location.href.replace(/^http:/, 'https:')
    </script>
    <!-- Google Analytics -->
    <script>
        window.ga = window.ga || function () {
            (ga.q = ga.q || []).push(arguments)
        };
        ga.l = +new Date;
        ga('create', '', 'auto');
        ga('send', 'pageview');
    </script>
    <script async src='../www.google-analytics.com/analytics.js'></script>
    <!-- End Google Analytics -->
    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyClzIF4LWaBhojQMgDhZwps1UKPpjmF8EU&amp;callback=initMap">
        </script>