    <header id="header">

			<div class="call-div">
					<div class="container">
					<div class="row">
					<div class="col-sm-12">
					Call Us Now: <a href="tel:09993357325">09993357325</a>
					</div>
					</div>
					</div>
					</div>

        <div id="topbar">
            <div class="container" >
                <div class="social-links">
                    <a><b> +91-9993357325</b> </a>
                    <a target="_blank"  title="Presently Solutions" href="https://www.facebook.com/presentlysolutions" class="facebook"><i class="fa fa-facebook"></i></a>
                    <a target="_blank" title="Presently Solutions" href="https://www.linkedin.com/company/presentlysolutions" class="linkedin"><i
                            class="fa fa-linkedin"></i></a>
							 <a target="_blank" title="Presently Solutions" href="https://www.twitter.com/presentlyindia" class="twitter"><i class="fa fa-twitter"></i></a>
							  <a target="_blank" title="Presently Solutions" href="https://www.instagram.com/presentlysolutions" class="instagram"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
        </div>

        <div class="container">

            <div class="logo float-left">
                <!-- comment below if you prefer to use an image logo -->
                <!-- <h1 class="text-light"><a href="#intro" class="scrollto"><span>Presently It</span></a></h1> -->
                <a href="#" class="scrollto"><img src="img/logo.png" alt="" class="img-fluid"><b style="font-size:18px;" > Presently Solutions</b></a>
                <!-- <a href="../stripe/stripe/index.html" class="scrollto"><img src="img/logo.png" alt="" class="img-fluid"><b style="font-size:18px;"> Presently Solutions</b></a> -->
            </div>


            <nav class="main-nav float-right d-none d-lg-block">
                <ul>
                    <li class="active"><a href="index.php">Home</a></li>
                    
					<li class="drop-down" style="padding-left:2px;"><a href="#pro3">Presently</a>
					 <ul>
              <li ><a href="Who-We-Are.php">Who We Are</a></li>
              <li ><a href="our-team.php">Our Team</a></li>
              <li><a href="career.php">Career</a></li>
			 
              
                </ul>
					</li>
					
					<li><a href="portfolio.php">Portfolio </a></li>
					
					
					 <li class="drop-down" ><a href="#products2" >Products</a>
					 <ul>
              <li ><a href="hr-management-software-in-india.php">HRM SOFTWARE</a></li>
              <li ><a href="erp-software-india.php">ERP SOFTWARE</a></li>
              <li ><a href="crm-software.php">CRM SOFTWARE </a></li>
              <li ><a href="school-management.php">SM SOFTWARE</a></li>
              
                </ul>
					</li>
                    <li class="drop-down" ><a href="#products1" >Services</a>
					 <ul>
              <li ><a href="website-development-services.php">Websites Development</a></li>
              <li ><a href="web-application-development.php">Web Applications</a></li>
              <li ><a href="creative-branding.php">Graphics & Logo Designing</a></li>
              <li ><a href="digital-marketing.php">Digital Marketing</a></li>
              <li ><a href="domain-&-hosting.php">Domain And Hosting</a></li>
                </ul>
					</li>
					
                    <li><a href="blog.php">Blog</a></li>
       
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </nav><!-- .main-nav -->

        </div>
    </header>
	
		<style>
.inner-banner{
		
		padding:43px;
		padding-top:80px;
		padding-bottom:90px;
		background-image:url('img/b1.jpg');
		-webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
	}
	#main{margin-top:130px;}
	.call-div{display:none}
	.text-center {
    text-align: center;
}
.box{background-color:red;}
.inner-banner .box {
    display: inline-block;
    border: 3px solid #fff;
    padding: 11px 47px;
}
	
	.inner-banner h3 {
    margin: 0;
    font-size: 40px;
    line-height: 42px;
    color: #fff;
    font-weight: 700;
}



@media (max-width:800px){
.inner-banner h3 {
    font-size: 25px;
}
.inner-banner {
padding-top:40px;
	padding-bottom:40px;
	padding:30px; 
}

#main{margin-top:80px;}
		
.call-div{display:block !important; bottom:0px; position:fixed; width:100%; z-index:1000; bottom:0; background:white; text-align:center; padding:10px; color:Black;}
.call-div a{color:#90b777;}

.contactspp{
		display:none;
}
.whatspp{
		display: block;
		position: fixed;
		bottom: 15%;
		left: 0%;
		height: 70px;
		height: 70px;
		width: 70px;
		left: auto;
		 z-index:111;
}
.whatspp img{
	height: 50px;
	width: 50px;
}

}



 </style>