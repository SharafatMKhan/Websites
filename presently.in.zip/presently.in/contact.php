<!DOCTYPE html>
<html lang="en">


<head>
        <title>Contact Us | Presently Solutions | Software Development Company</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
        content="We are US based  software company in India that offers abundant software services and  solutions to minimise work and maximise the success of your business."
        property="description">
    <meta name="author" content="Presently Solutions" property="author">
    <meta name="canonical" content="https://presently.in/contact.php" property="canonical">
    <meta name="robots" content="Index, follow">
    <meta name="og:title" content="Presently Solutions:Top IT Company " property="og:title">
    <meta name="og:description" content="Presently Solutions software development company in Bhopal,India"
        property="og:description">
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <meta name="keywords" content="Leading It company in Bhopal,Customized software service,Web design and development,
         mobile app development, Software solutions,app developers, web application and development, leading software solution provider in Bhopal,India,Dynamic Websites,Bhopal web development, Bhopal mobile app development, Bhopal app developer, Bhopal web design, Bhopal logo design,
         US based IT company in Thrissur,Custom developed websites,WebSite Hosting,software support and solutions in Bhopal,India,
         Professionals in software development, Best software company in Central India " property="keywords">
    <meta name="keyphrase"
        content="Best Software company in thrissur, Top IT company in Bhopal,software solutions,
                Website design and development company Bhopal,IOS and Andoird application development company Thrissur" />
    <meta name="topic" content="Software" />
    <meta name="subject" content="Contact Us" />
    <meta name="classification" content="Software,Website development,Leading,Best,Top Company" />
    <meta name="rating" content="general">
    <meta name="audience" content="all" />
    <meta property="og:type" content="Software Company" />
    <meta property="og:url" content="https://www.facebook.com/presentlysolutions/" />
    <meta property="og:site_name" content="www.Presently.in" />
    <meta name="og:image" content="img/companyculture.png" />
    <meta name="og:email" content=" info@presently.in" />
    <meta name="og:phone_number" content="+919993357325" />
    <meta itemprop="name" content="Software Company, Bhopal" />
    <meta itemprop="description"
        content="Presently Soultions is the top web designing and web development in Bhopal who offers attractive website designs with creative web designers in Bhopal" />
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <link rel="canonical" href="index.php" />
    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
  
    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700"
        rel="stylesheet">
    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">


</head>

<body>
    <!--==========================
  Header
  ============================-->
<?php include("part/header.php"); ?>
<!-- #header -->
	

    <main id="main">

	 <section  class="inner-banner text-center" style="background-image:url('img/bannercontact.jpg')">
            <div class="container">
                <div class="box">
                    <h3 id="headtop">
                     Contact</h3>
                </div>
            </div>
</section>

        <!--==========================
      About Us Section
    ============================-->
        <section id="about">

            <div class="container">
                <div class="row" id="footer" class="section-bg">

                    <div class="col-lg-5 col-md-6" style="line-height: 2;">
                       <div class="footer-links">
                                    <h4>Contact Us</h4>
                                    <p>
                                        Plot No. B229 Indra Nagar ,<br>
                                        Om Sai Ram Multicomplex, Mandideep, Bhopal(M.P) 462046 <br>
                                        <strong>Email:</strong>
                                        <a href="mailto:info@presently.in">info@presently.in</a><br>
                                        <strong>Contact No:</strong>
                                        <a href="callto:9993357325">9993357325</a>
                                    </p>
                                </div>
                    </div>

                     <div class="col-lg-6">

                        <div class="form">

                            <h4>KEEP IN TOUCH</h4>
                            <p> We'd <span class="love">&#9825;</span> to help! &nbsp;&nbsp; If you want something else
                                there, should
                                be focused on their project or area of interest, such us, Please share with us your idea
                                or project.</p>
                            <form
                                action="contact-post.php"
                                method="post" role="form" class="contactForm">
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control" id="name"
                                        placeholder="Your Name" data-rule="minlen:4"
                                        data-msg="Please enter at least 4 chars" />
                                    <div class="validation"></div>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" name="email" id="email"
                                        placeholder="Your Email" data-rule="email"
                                        data-msg="Please enter a valid email" />
                                    <div class="validation"></div>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="subject" id="subject"
                                        placeholder="Subject" data-rule="minlen:4"
                                        data-msg="Please enter at least 8 chars of subject" />
                                    <div class="validation"></div>
                                </div>
                                <div class="form-group">
                                    <textarea class="form-control" name="message" rows="5" data-rule="required"
                                        data-msg="Please write something for us" placeholder="Message"></textarea>
                                    <div class="validation"></div>
                                </div>

                             

                                <div class="text-center"><button type="submit" name="submits" style="padding:7px 35px 7px 35px; background:#25538c; color:white;" title="Send Message">Send
                                        Message</button></div>
                            </form>
                        </div>

                    </div>
                </div>

            </div>

        </section><!-- #about -->

       
     <!-- <main id="main">

       Map Section   
        <div class="map ">
            <div id="map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2506.370150684341!2d-93.62722918566868!3d41.66453022459714!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87ee9b00970c41d5%3A0x4193fe58d6e8120e!2s5730+NW+4th+Ct%2C+Des+Moines%2C+IA+50313!5e0!3m2!1sen!2sus!4v1524641845645" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>	
            </div>
			
			<div style="width: 100%"><iframe width="100%" height="600" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=event%20mahotsav%20mandideep+(Presently%20Solution)&amp;t=&amp;z=12&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></div>
        </div>  -->
          <div class="container">
            <div class="owl-carousel clients-carousel">
                <img src="img/logos/angular.png" style="width:150px;padding:20px" alt="">
                <img src="img/logos/html1.png" style="width:150px;padding:20px" alt="">
                <img src="img/logos/ios.png" style="width:80px;padding:1px 0px;" alt="">
                <img src="img/logos/android.png" style="width:80px;padding:1px 0px" alt="">
                <img src="img/logos/php.png" style="width:100px;padding:10px" alt="">
                <img src="img/logos/css.png" style="width:80px;padding:10px" alt="">
                <img src="img/logos/laravel.png" style="width:160px;padding:20px" alt="">
            </div>
        </div>

  </main>
    <!--==========================
    Footer
  ============================-->
  <?php include("part/footer.php"); ?>
  <!-- #footer -->

   

</body>


</html>