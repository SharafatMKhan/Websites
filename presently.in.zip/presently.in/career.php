<!DOCTYPE html>
<html lang="en">


<head>
    <title>Career | Presently Solutions | Software Development Company</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="At Presently, we make BRANDS AND BUSINESSES achieve exponential success by effectively leveraging the combined power of Mobile, Social Media, Web, Videos and Data Analytics to excite and engage consumers." property="description">
    <meta name="author" content="Presently Solutions" property="author">
    <meta name="canonical" content="https://presently.in/" property="canonical">
    <meta name="robots" content="Index, follow">
    <meta name="og:title" content="Presently Solutions:Top IT Company " property="og:title">
    <meta name="og:description" content="Presently Solutions software development company in Bhopal,India" property="og:description">
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <meta name="keywords" content="Leading It company in Bhopal,Customized software service,Web design and development,
         mobile app development, Software solutions,app developers, web application and development, leading software solution provider in Bhopal,India,Dynamic Websites,Bhopal web development, Bhopal mobile app development, Bhopal app developer, Bhopal web design, Bhopal logo design,
         US based IT company in Thrissur,Custom developed websites,WebSite Hosting,software support and solutions in Bhopal,India,
         Professionals in software development, Best software company in Central India " property="keywords">
    <meta name="keyphrase" content="Best Software company in thrissur, Top IT company in Bhopal,software solutions,
                Website design and development company Bhopal,IOS and Andoird application development company Thrissur" />
    <meta name="topic" content="Software" />
    <meta name="subject" content="Career" />
    <meta name="classification" content="Software,Website development,Leading,Best,Top Company" />
    <meta name="rating" content="general">
    <meta name="audience" content="all" />
    <meta property="og:type" content="Software Company" />
    <meta property="og:url" content="https://www.facebook.com/presentlysolutions/" />
    <meta property="og:site_name" content="www.Presently.in" />
    <meta name="og:image" content="img/companyculture.png" />
    <meta name="og:email" content=" info@presently.in" />
    <meta name="og:phone_number" content="+919993357325" />
    <meta itemprop="name" content="Software Company, Bhopal" />
    <meta itemprop="description" content="Presently Soultions is the top web designing and web development in Bhopal who offers attractive website designs with creative web designers in Bhopal" />
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <link rel="canonical" href="index.php" />
    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700" rel="stylesheet">
    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">
    <!--  Career css link -->
    <link rel="stylesheet" href="./css/career.css">


</head>

<body>
    <!--==========================
  Header
  ============================-->
    <?php include("part/header.php"); ?>
    <!-- #header -->


    <main id="main">

        <section class="inner-banner text-center" style="background-image:url('img/career.jpg')">
            <div class="container">
                <div class="box">
                    <h3 id="headtop">
                        Career</h3>
                </div>
            </div>
        </section>


        <!--==========================
      Pricing Section
    ============================-->
        <section id="pricing" class="wow fadeInUp section-bg">

            <div class="container">

                <header class="section-header">
                    <h3>Career</h3>
                    <p>We are offering a highly competitive salary with fringe benefits, a dynamic work environment and
                        opportunities for your personal
                        and proffesional growth.<br /> Apply with your resume detailing your qualification and work
                        experience.<br />

                        <b>Email</b> : <a href="mailto:info@presently.in"> info@presently.in</a>
                    </p>
                </header>

                <div class="row flex-items-xs-middle flex-items-xs-center">
                    <div class="col-xs-12 col-lg-12">
                        <ul id="faq-list" class="wow fadeInUp">
                            <li>
                                <a data-toggle="collapse" class="collapsed" href="#php">PHP Developer <i class="ion-android-remove"></i></a>
                                <div id="php" class="collapse" data-parent="#faq-list">
                                    <p>
                                        Presently It Solutions has an open job position for a <b>talented</b> Jr PHP Developer with <b>minimum 1
                                            years</b> of technology experience.
                                    </p>
                                    <div class="inner-box" style="padding-left: 80px">


                                        <strong>Experience:</strong> 1 - 3 Years<br>
                                        <strong>Job Location:</strong> MP Nagar, Bhopal/ Mandideep<br>
                                        <strong>Job Type:</strong> Full Time/ Part Time</br>

                                        </br>

                                        <h4 style="font-weight: 300;">Key Role Area</h4>
                                        <ul class="basic-listing">
                                            <li>Minimum 1 - 3yrs of experience of software development experience using CodeIgniter, Laravel, Zend, Opencart & Cake PHP</li>
                                            <li>Responsible for Developing High Quality Web Applications like CMS, E-Commerce Portal & Software Development</li>
                                            <li>The Candidate should Create Themes, Modules, CMS (Content Management System)/li>
                                            <li>The Candidate should Implement APIs, Payment Gateways and other APIs in existing as well as new applications.</li>
                                            <li>The Candidate should Create web applications in CodeIgniter, Laravel, Zend, Opencart & Cake PHP.</li>
                                            <li>The Candidate should Develop and deploy new features to facilitate related procedures and tools if necessary.</li>
                                            <li>The Candidate sholud have a good knowledge of web Application including HTML, Angular.Js, Node.Js, JQuery,
                                                CSS, Javascript, AJAX Etc..</li>
                                            <li>Should have experience with web services standards and related technologies (XML, JSON)</li>
                                            <li>Experience of databases for example: MySQL & MYSQLi</li>
                                            <li>The candidate should create (Dynamic URL, Dynamic title, Dynamic description, Dynamic Sitemap) </li>
                                        </ul>

                                        </br>
                                        <h4 style="font-weight: 300;">Requirements</h4>
                                        <ul class="basic-listing">
                                            <li>Good communication, self motivator, team player, ability to solve complex problems, design & requirements documentation.</li>
                                            <li>Excellent communication & Strong Organization, Interpersonal and Analytical skills.</li>
                                            <li>Able to work without a team.</li>
                                            <li>Responsible for Timely delivery.</li>
                                        </ul></br>
                                        <p>
                                            <strong>Keywords / Skills:</strong> CodeIgniter, Laravel, Zend, Opencart & Cake PHP, design patterns, data structures, Angular.Js, Node.Js, JQuery,
                                            CSS, Javascript,MySQL & MYSQLi<br>
                                            <br>
                                            <strong>No of Positions:</strong> 2 - 3<br>
                                            <br>
                                            <strong>Job Location :</strong> Bhopal<br>
                                            <br>
                                            <strong>Eligibility:</strong> B.Tech/B.E. - Computers,PG - M.Tech - Computers, MS/M.Sc(Science) - Computers, MCA - Computers
                                            <br>
                                            <br>
                                            <!-- Form -->
                                            <button class="open-button" onclick="openForm()">Open Form</button>

                                        <div class="form-popup" id="myForm">
                                            <form action="/action_page.php" class="form-container">
                                                <h1>We will get back to you</h1>
                                                <label for="psw"><b>Name</b></label>
                                                <input type="text" placeholder="Enter Name" name="psw" required>

                                                <label for="email"><b>E-mail</b></label>
                                                <input type="text" placeholder="Enter Email" name="email" required>

                                                <label for="psw"><b>Experience</b></label>
                                                <input type="password" placeholder="Enter Experience" name="psw" required>

                                                <label for="myfile">Upload Your Resume</label>
                                                <input type="file" id="myfile" name="myfile"><br><br>

                                                <button type="submit" class="btn">Submit</button>
                                                <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
                                            </form>
                                        </div>
                                        <!-- Form -->


                                        </p>
                                        <br>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <a data-toggle="collapse" class="collapsed" href="#content">Content Writer <i class="ion-android-remove"></i></a>
                                <div id="content" class="collapse" data-parent="#faq-list">
                                    <p>
                                        Presently It Solutions has an open job position for a <b>talented</b> Sales
                                        Consultant with <b>minimum 2
                                            years</b> of technology sales experience.
                                    </p>
                                    <strong>Experience:</strong> 1 - 2 Years<br>
                                    <strong>Job Location:</strong> MP Nagar, Bhopal<br>
                                    <strong>Job Type:</strong> Full Time<br>

                                    <p style="text-align:justify">An efficient Content Writer is required with a minimum experience of 1 years and excellent command of language. He/She will be working under proficient Managers of DVInfosoft Pvt Ltd as per the standards of the work. Proficiency in technical writing, non-technical writing, Copy Writing, Article, Blogs, and Social Media work must be possessed.</p>
                                    <br />

                                    <h4 style="font-weight: 300;">JOB DESCRIPTION</h4>
                                    <ul class="basic-listing">
                                        <li>Familiarity with keyword placements in Content work.</li>
                                        <li>Impeccable spelling and writing.</li>
                                        <li>Understanding of Consumers and Market.</li>
                                        <li>Must comply with deadlines and able to work under pressure.</li>
                                        <li>Excellent command in English language</li>
                                        <li>Fluency in speech and coherence in writing content.</li>
                                    </ul></br>
                                    <h4 style="font-weight: 300;">BASIC REQUIREMENTS</h4>
                                    <ul class="basic-listing">
                                        <li>1 years of experience</li>
                                        <li>Fluent English (Writing + Speaking)</li>
                                        <li>Education: High School or Equivalent.</li>

                                    </ul>
                                    <p>
                                        <strong>SALARY - </strong> 10,000 To 2,0000 Per Month as per experience. <br>
                                        <br>

                                        Interested Candidate must attach their CV and send us
                                        <br>
                                        <br>

                                        <!-- Form -->
                                        <button class="open-button" onclick="openForm1()">Open Form</button>

                                    <div class="form-popup" id="myForm1">
                                        <form action="/action_page.php" class="form-container">
                                            <h1>We will get back to you</h1>
                                            <label for="psw"><b>Name</b></label>
                                            <input type="text" placeholder="Enter Name" name="psw" required>

                                            <label for="email"><b>E-mail</b></label>
                                            <input type="text" placeholder="Enter Email" name="email" required>

                                            <label for="psw"><b>Experience</b></label>
                                            <input type="password" placeholder="Enter Experience" name="psw" required>

                                            <label for="myfile">Upload Your Resume</label>
                                            <input type="file" id="myfile" name="myfile"><br><br>

                                            <button type="submit" class="btn">Submit</button>
                                            <button type="button" class="btn cancel" onclick="closeForm1()">Close</button>
                                        </form>
                                    </div>

                                    </p>
                                    <br>
                                </div>
                            </li>
                            <li>
                                <a data-toggle="collapse" class="collapsed" href="#faq1">Sales Consultant <i class="ion-android-remove"></i></a>
                                <div id="faq1" class="collapse" data-parent="#faq-list">
                                    <p>
                                        Presently It Solutions has an open job position for a <b>talented</b> Sales
                                        Consultant with <b>minimum 2
                                            years</b> of technology sales experience.
                                    </p>
                                    <strong>Experience:</strong> 0 - 2 Years<br>
                                    <strong>Job Location:</strong> MP Nagar, Bhopal<br>
                                    <strong>Job Type:</strong> Full Time/ Part Time<br>
                                    </br>
                                    <h4 style="font-weight: 300;">Key Role Area</h4>
                                    <ul class="basic-listing">
                                        <li>Capable of representing solutions / services to business users</li>
                                        <li>Strong negotiation and business development skills. Ability to manage multiple situations and retain clear and account plans during the busiest of situations</li>
                                        <li>Call & set-up appointments on daily basis, and meet pre-defined set of prospective clients on daily basis</li>
                                        <li>Candidate should take care of marketing and sales activities of the company.</li>
                                        <li>To make presentations to the clients and convert them into sales.</li>
                                        <li>To develop and maintain relations with the client and generate sales from references.</li>
                                        <li>Deal with Decision Makers</li>
                                        <li>Having exposure in Software / Website marketing will be an additional benefit</li>
                                        <li>Following up with the customers for closures.</li>
                                        <li>To create/maintain excellent relationships with clients and be able to tailor products pitch according to their specifications.</li>
                                        <li>A strong commitment to customer service.</li>
                                        <li>Developing new ideas to achieve sales growth Interact regularly with the clients to ensure a committed and partnership based relationship.</li>
                                    </ul>
                                    </br>
                                    <h4 style="font-weight: 300;">Requirements</h4>
                                    <ul class="basic-listing">
                                        <li>Excellent communication &amp; presentation skills.</li>
                                        <li>Having basic knowledge of computers, Internet, websites and Software</li>
                                        <li>Decision making ability even in stressful situations</li>
                                        <li>Two Wheeler is must with valid license.</li>
                                        <li>Able to work without a team</li>
                                        <li>Candidates working in same industry will get the good benefits from us.</li>
                                        <li>Should have a proven track record in generating sales.</li>
                                        <li>Willing to travel &amp; conduct client meetings</li>
                                        <li>Strong motivation and a burning desire to succeed</li>
                                        <li>Self Starter approach</li>
                                        <li>Happy to work in a performance based environment</li>
                                    </ul>
                                    <p></br>
                                        <strong>Keywords / Skills:</strong> Pre sales, Sales BD<br>
                                        <br>
                                        <strong>No of Positions:</strong> 0 - 2<br>
                                        <br>
                                        <strong>Job Location :</strong> Bhopal<br>
                                        <br>
                                        <strong>Eligibility:</strong> B.E. / B.Tech / MCA / MBA / PGDM / Any Graduate / P.G - Any Diploma / Any Degree / Any Specialization - (B.E. or M.B.A. would be a preference)
                                        <br>
                                        <br>
                                        <button class="open-button" onclick="openForm2()">Open Form</button>

                                    <div class="form-popup" id="myForm2">
                                        <form action="/action_page.php" class="form-container">
                                            <h1>We will get back to you</h1>
                                            <label for="psw"><b>Name</b></label>
                                            <input type="text" placeholder="Enter Name" name="psw" required>

                                            <label for="email"><b>E-mail</b></label>
                                            <input type="text" placeholder="Enter Email" name="email" required>

                                            <label for="psw"><b>Experience</b></label>
                                            <input type="password" placeholder="Enter Experience" name="psw" required>

                                            <label for="myfile">Upload Your Resume</label>
                                            <input type="file" id="myfile" name="myfile"><br><br>

                                            <button type="submit" class="btn">Submit</button>
                                            <button type="button" class="btn cancel" onclick="closeForm2()">Close</button>
                                        </form>
                                    </div>
                                    </p>
                                </div>
                            </li>
                            <li>
                                <a data-toggle="collapse" class="collapsed" href="#seo">SEO Developer <i class="ion-android-remove"></i></a>
                                <div id="seo" class="collapse" data-parent="#faq-list">

                                    <strong>Experience:</strong> 1 - 2 Years<br>
                                    <strong>Job Location:</strong> MP Nagar, Bhopal<br>
                                    <strong>Job Type:</strong> Full Time<br>

                                    <p style="text-align:justify">An efficient <b>SEO</b> Developer is required for DVInfosoft Pvt Ltd.. Proficiency in technical and non-technical management and Social Media knowledge is a must. He/she must possess minimum work experience of 2 years and excellent command of market research. Proficient Managers of DVInfosoft Pvt Ltd. will be guiding the selected candidates as per the standards of the work. The process of improving quality volume of web traffic to a website will be the main responsibility of the job.</p>
                                    <br />
                                    <h4 style="font-weight: 200;">JOB DESCRIPTION</h3>
                                        <ul class="basic-listing">
                                            <li>Familiarity with keyword placements and Search Engine Optimization work.</li>
                                            <li>Responsible for analyzing, reviewing and implementing websites, optimized to be picked up by search engine.</li>
                                            <li>Search Engine Submission, Social Bookmarking, Article, Blog, Profile listings.</li>
                                            <li>Develop SEO Strategies to include keywords for increasing web traffic.</li>
                                            <li>Must comply with deadlines and able to work under pressure.</li>
                                            <li>Deliver the good work for clients’ websites and submit the report.</li>
                                            <li>Improve page rank with proven SEO techniques.</li>
                                            <li>Improve the rank of the clients websites.</li>
                                            <li>Great knowledge of Website Structred Layout, Meta Tags, REL canonical Tag, Schema, ALT Tags.</li>
                                            <li>Great knowledge Social Media Promotion to increase the web traffic.</li>
                                            <li>YouTube Promotion by creating a channel, optimizing the video.
                                            </li>
                                        </ul>
                                        <h4 style="font-weight: 200;">BASIC REQUIREMENTS</h3>
                                            <ul class="basic-listing">
                                                <li>2 years of experience in SEO, designing, layouts and advertising techniques to gain most of the organic traffic to the websites.</li>
                                                <li>Fluent English (Writing + Speaking)</li>
                                                <li>Education: High School or Equivalent.</li>

                                            </ul>
                                            <p>
                                                <strong>SALARY - </strong> 10,000 To 1,5000 Per Month as per experience. <br>
                                                <br>
                                                Interested Candidate must attach their CV and send us
                                                <br>
                                                <br>

                                                <button class="open-button" onclick="openForm3()">Open Form</button>

                                            <div class="form-popup" id="myForm3">
                                                <form action="/action_page.php" class="form-container">
                                                    <h1>We will get back to you</h1>
                                                    <label for="psw"><b>Name</b></label>
                                                    <input type="text" placeholder="Enter Name" name="psw" required>

                                                    <label for="email"><b>E-mail</b></label>
                                                    <input type="text" placeholder="Enter Email" name="email" required>

                                                    <label for="psw"><b>Experience</b></label>
                                                    <input type="password" placeholder="Enter Experience" name="psw" required>

                                                    <label for="myfile">Upload Your Resume</label>
                                                    <input type="file" id="myfile" name="myfile"><br><br>

                                                    <button type="submit" class="btn">Submit</button>
                                                    <button type="button" class="btn cancel" onclick="closeForm3()">Close</button>
                                                </form>
                                            </div>

                                            </p>
                                            <br>
                                </div>
                            </li>
                            <li>
                                <a data-toggle="collapse" class="collapsed" href="#faq2">Digital Marketing consultant <i class="ion-android-remove"></i></a>
                                <div id="faq2" class="collapse" data-parent="#faq-list">
                                    <p>
                                        Presently It Solutions Inc is seeking to ﬁll our Digital Marketing consultant
                                        position with an
                                        enthusiastic, career minded, individual, with a strong work ethic and a
                                        commitment to teamwork. </p>

                                    </p>
                                    <button class="open-button" onclick="openForm4()">Open Form</button>

                                    <div class="form-popup" id="myForm4">
                                        <form action="/action_page.php" class="form-container">
                                            <h1>We will get back to you</h1>
                                            <label for="psw"><b>Name</b></label>
                                            <input type="text" placeholder="Enter Name" name="psw" required>

                                            <label for="email"><b>E-mail</b></label>
                                            <input type="text" placeholder="Enter Email" name="email" required>

                                            <label for="psw"><b>Experience</b></label>
                                            <input type="password" placeholder="Enter Experience" name="psw" required>

                                            <label for="myfile">Upload Your Resume</label>
                                            <input type="file" id="myfile" name="myfile"><br><br>

                                            <button type="submit" class="btn">Submit</button>
                                            <button type="button" class="btn cancel" onclick="closeForm4()">Close</button>
                                        </form>
                                    </div>
                            </li>
                            <li>
                                <a data-toggle="collapse" class="collapsed" href="#faq3">Angular 2+ Developer <i class="ion-android-remove"></i></a>
                                <div id="faq3" class="collapse" data-parent="#faq-list">
                                    <p>
                                        Presently It SOLUTIONS is looking for a talented and Experienced
                                        <b>Angular developer</b>. As an ideal candidate, you must have
                                        <b>minimum 1 year of experinece</b> in web Development.
                                    </p>
                                    <h4>SKILLS REQUIRED</h4>
                                    <ul>
                                        <li>Strong Experience with Angular 2+</li>
                                        <li>Experience in HTML5, CSS3, Bootstrap</li>
                                        <li>TypeScript</li>
                                        <li>Angular Material</li>
                                        <li>REST API</li>
                                    </ul>
                                    <button class="open-button" onclick="openForm5()">Open Form</button>

                                    <div class="form-popup" id="myForm5">
                                        <form action="/action_page.php" class="form-container">
                                            <h1>We will get back to you</h1>
                                            <label for="psw"><b>Name</b></label>
                                            <input type="text" placeholder="Enter Name" name="psw" required>

                                            <label for="email"><b>E-mail</b></label>
                                            <input type="text" placeholder="Enter Email" name="email" required>

                                            <label for="psw"><b>Experience</b></label>
                                            <input type="password" placeholder="Enter Experience" name="psw" required>

                                            <label for="myfile">Upload Your Resume</label>
                                            <input type="file" id="myfile" name="myfile"><br><br>

                                            <button type="submit" class="btn">Submit</button>
                                            <button type="button" class="btn cancel" onclick="closeForm5()">Close</button>
                                        </form>
                                    </div>

                            </li>
                            <li>
                                <a data-toggle="collapse" class="collapsed" href="#faq4">Graphic Designer <i class="ion-android-remove"></i></a>
                                <div id="faq4" class="collapse" data-parent="#faq-list">
                                    <p>
                                        Presently It SOLUTIONS is looking for a talented and Experienced
                                        <b>Graphic Designer</b>. As an ideal candidate, you must have
                                        <b>1-4 years of experinece</b> in web Designing and Banners.
                                    </p>

                                    <strong>Experience:</strong> 1 - 2 Years<br>
                                    <strong>Job Location:</strong> MP Nagar, Bhopal<br>
                                    <strong>Job Type:</strong> Full Time/ Part Time<br>
                                    </br>
                                    <h4 style="font-weight: 300;">Key Role Area</h4>
                                    <ul class="basic-listing">
                                        <li>Knowledge of Adobe Photoshop / Corel Draw, Illustrator.</li>
                                        <li>Ability to create fresh designs, banners for website & Social Promotions, logo images, icons,
                                            brochures etc.</li>
                                        <li>Should involve in designing advertisements, handouts, flyers & online graphics.</li>
                                        <li>Producing graphic content for site re-skins, page layouts, site graphics, email designs.</li>
                                        <li>Designing presentations & case study materials.</li>
                                        <li>Print Designs & layouts.</li>
                                    </ul></br>
                                    <h4 style="font-weight: 300;">Requirements</h4>
                                    <ul class="basic-listing">
                                        <li>Candidate should be able to think out of the box and should be very flexible.</li>
                                        <li>Keep up with trends and recommend changes and updates accordingly.</li>
                                        <li>Responsible for Timely delivery.</li>
                                        <li>Creative design sense, Creative thinking</li>
                                        <li>Good communication, self motivator, team player, ability to solve complex problems, design &
                                            requirements documentation.</li>
                                    </ul></br>
                                    <p>
                                        <strong>Keywords / Skills:</strong> Adobe Photoshop, Illustrator, Corel Draw.D<br>
                                        <br>
                                        <strong>No of Positions:</strong> 1 - 2<br>
                                        <br>
                                        <strong>Job Location :</strong> Bhopal<br>
                                        <br>
                                        <strong>Eligibility:</strong> B.E. / B.Tech / MCA - Any Graduate / P.G - Any Diploma / Any Degree / Any Specialization
                                        <br>
                                        <br>

                                        <button class="open-button" onclick="openForm6()">Open Form</button>

                                    <div class="form-popup" id="myForm6">
                                        <form action="/action_page.php" class="form-container">
                                            <h1>We will get back to you</h1>
                                            <label for="psw"><b>Name</b></label>
                                            <input type="text" placeholder="Enter Name" name="psw" required>

                                            <label for="email"><b>E-mail</b></label>
                                            <input type="text" placeholder="Enter Email" name="email" required>

                                            <label for="psw"><b>Experience</b></label>
                                            <input type="password" placeholder="Enter Experience" name="psw" required>

                                            <label for="myfile">Upload Your Resume</label>
                                            <input type="file" id="myfile" name="myfile"><br><br>

                                            <button type="submit" class="btn">Submit</button>
                                            <button type="button" class="btn cancel" onclick="closeForm6()">Close</button>
                                        </form>
                                        </p>
                                        <br>
                                    </div>
                            </li>
                            <li>
                                <a data-toggle="collapse" class="collapsed" href="#faq5">Web Developer / Programmer <i class="ion-android-remove"></i></a>
                                <div id="faq5" class="collapse" data-parent="#faq-list">
                                    <p>
                                        Presently It SOLUTIONS is looking for a talented and Experienced
                                        <b>PHP/MySQL</b>. As an ideal candidate, you must have
                                        <b>1-4 years of experinece</b> in web Development and internet based
                                        applications/database
                                        management systems.
                                    </p>
                                    <h4>SKILLS REQUIRED</h4>

                                    <ul>
                                        <li>Php</li>
                                        <li>MySQL</li>
                                        <li>jQuery</li>
                                        <li>Bootstrap</li>
                                        <li>Ajax</li>
                                    </ul>
                                    <button class="open-button" onclick="openForm7()">Open Form</button>

                                    <div class="form-popup" id="myForm7">
                                        <form action="/action_page.php" class="form-container">
                                            <h1>We will get back to you</h1>
                                            <label for="psw"><b>Name</b></label>
                                            <input type="text" placeholder="Enter Name" name="psw" required>

                                            <label for="email"><b>E-mail</b></label>
                                            <input type="text" placeholder="Enter Email" name="email" required>

                                            <label for="psw"><b>Experience</b></label>
                                            <input type="password" placeholder="Enter Experience" name="psw" required>

                                            <label for="myfile">Upload Your Resume</label>
                                            <input type="file" id="myfile" name="myfile"><br><br>

                                            <button type="submit" class="btn">Submit</button>
                                            <button type="button" class="btn cancel" onclick="closeForm7()">Close</button>
                                        </form>
                                </div>
                            </li>


                        </ul>
                    </div>
                </div>
            </div>

        </section><!-- #pricing -->

        <script>
            function openForm() {
                document.getElementById("myForm").style.display = "block";
            }

            function closeForm() {
                document.getElementById("myForm").style.display = "none";
            }

            // -----------------------------------------------------------
            function openForm1() {
                document.getElementById("myForm1").style.display = "block";
            }

            function closeForm1() {
                document.getElementById("myForm1").style.display = "none";
            }
            // -------------------------------------
            function openForm2() {
                document.getElementById("myForm2").style.display = "block";
            }

            function closeForm2() {
                document.getElementById("myForm2").style.display = "none";
            }
            // ---------------------------------------
            function openForm3() {
                document.getElementById("myForm3").style.display = "block";
            }

            function closeForm3() {
                document.getElementById("myForm3").style.display = "none";
            }
            // ---------------------------------------
            function openForm4() {
                document.getElementById("myForm4").style.display = "block";
            }

            function closeForm4() {
                document.getElementById("myForm4").style.display = "none";
            }
            // ---------------------------------------
            function openForm5() {
                document.getElementById("myForm5").style.display = "block";
            }

            function closeForm5() {
                document.getElementById("myForm5").style.display = "none";
            }
            // ---------------------------------------
            function openForm6() {
                document.getElementById("myForm6").style.display = "block";
            }

            function closeForm6() {
                document.getElementById("myForm6").style.display = "none";
            }
            // ---------------------------------------
            function openForm7() {
                document.getElementById("myForm7").style.display = "block";
            }

            function closeForm7() {
                document.getElementById("myForm7").style.display = "none";
            }
        </script>

    </main>
    <!--==========================
    Footer
  ============================-->
    <?php include("part/footer.php"); ?>
    <!-- #footer -->



</body>


</html>