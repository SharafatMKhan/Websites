<!DOCTYPE html>
<html lang="en">


<head>
    <title>Presently Solutions | Software Development Company</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
        content="At Presently, we make BRANDS AND BUSINESSES achieve exponential success by effectively leveraging the combined power of Mobile, Social Media, Web, Videos and Data Analytics to excite and engage consumers."
        property="description">
        <title>Website Development | Presently Solutions | Software Development Company</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
        content="We are US based  software company in India that offers abundant software services and  solutions to minimise work and maximise the success of your business."
        property="description">
    <meta name="author" content="Presently Solutions" property="author">
    <meta name="canonical" content="https://presently.in/website-development-services.php" property="canonical">
    <meta name="robots" content="Index, follow">
    <meta name="og:title" content="Presently Solutions:Top IT Company " property="og:title">
    <meta name="og:description" content="Presently Solutions software development company in Bhopal,India"
        property="og:description">
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <meta name="keywords" content="Leading It company in Bhopal,Customized software service,Web design and development,
         mobile app development, Software solutions,app developers, web application and development, leading software solution provider in Bhopal,India,Dynamic Websites,Bhopal web development, Bhopal mobile app development, Bhopal app developer, Bhopal web design, Bhopal logo design,
         US based IT company in Thrissur,Custom developed websites,WebSite Hosting,software support and solutions in Bhopal,India,
         Professionals in software development, Best software company in Central India " property="keywords">
    <meta name="keyphrase"
        content="Best Software company in thrissur, Top IT company in Bhopal,software solutions,
                Website design and development company Bhopal,IOS and Andoird application development company Thrissur" />
    <meta name="topic" content="Software" />
    <meta name="subject" content="Website Development" />
    <meta name="classification" content="Software,Website development,Leading,Best,Top Company" />
    <meta name="rating" content="general">
    <meta name="audience" content="all" />
    <meta property="og:type" content="Software Company" />
    <meta property="og:url" content="https://www.facebook.com/presentlysolutions/" />
    <meta property="og:site_name" content="www.Presently.in" />
    <meta name="og:image" content="img/companyculture.png" />
    <meta name="og:email" content=" info@presently.in" />
    <meta name="og:phone_number" content="+919993357325" />
    <meta itemprop="name" content="Software Company, Bhopal" />
    <meta itemprop="description"
        content="Presently Soultions is the top web designing and web development in Bhopal who offers attractive website designs with creative web designers in Bhopal" />
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <link rel="canonical" href="index.php" />

    <!-- CSS file webs_style.css -->
    <link rel="stylesheet" href="./css/web_style.css">
    <!--  -->
    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <!-- Google Fonts -->
    <!-- Bootstarp file -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700"
        rel="stylesheet">
        
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.0-beta2/css/bootstrap.min.css' integrity='sha512-aqT9YD5gLuLBr6ipQAS+72o5yHKzgZbGxEh6iY8lW/r6gG14e2kBTAJb8XrxzZrMOgSmDqtLaF76T0Z6YY2IHg==' crossorigin='anonymous'/>    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">

    <script src='../www.google.com/recaptcha/api.js'></script>
    <meta name="author" content="Presently Solutions" property="author">
    <meta name="canonical" content="https://presently.in/" property="canonical">
    <meta name="robots" content="Index, follow">
    <meta name="og:title" content="Presently Solutions:Top IT Company " property="og:title">
    <meta name="og:description" content="Presently Solutions software development company in Bhopal,India"
        property="og:description">
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <meta name="keywords" content="Leading It company in Bhopal,Customized software service,Web design and development,
         mobile app development, Software solutions,app developers, web application and development, leading software solution provider in Bhopal,India,Dynamic Websites,Bhopal web development, Bhopal mobile app development, Bhopal app developer, Bhopal web design, Bhopal logo design,
         US based IT company in Thrissur,Custom developed websites,WebSite Hosting,software support and solutions in Bhopal,India,
         Professionals in software development, Best software company in Central India " property="keywords">
    <meta name="keyphrase"
        content="Best Software company in thrissur, Top IT company in Bhopal,software solutions,
                Website design and development company Bhopal,IOS and Andoird application development company Thrissur" />
    <meta name="topic" content="Software" />
    <meta name="subject" content="Software" />
    <meta name="classification" content="Software,Website development,Leading,Best,Top Company" />
    <meta name="rating" content="general">
    <meta name="audience" content="all" />
    <meta property="og:type" content="Software Company" />
    <meta property="og:url" content="https://www.facebook.com/presentlysolutions/" />
    <meta property="og:site_name" content="www.Presently.in" />
    <meta name="og:image" content="img/companyculture.png" />
    <meta name="og:email" content=" info@presently.in" />
    <meta name="og:phone_number" content="+919993357325" />
    <meta itemprop="name" content="Software Company, Bhopal" />
    <meta itemprop="description"
        content="Presently Soultions is the top web designing and web development in Bhopal who offers attractive website designs with creative web designers in Bhopal" />
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <link rel="canonical" href="index.php" />
    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <link href="img/apple-touch-icon.html" rel="apple-touch-icon">
    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700"
        rel="stylesheet">
    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.0-beta2/css/bootstrap-grid.min.css' integrity='sha512-moLwE39aHmOrh2go4i0UKv4RvOqS4V42zyyIUjGDbL5fOymDSMJSOxZGl+jgccLh8cVzzu9tKSuDhBvq7RJ6wA==' crossorigin='anonymous'/>
    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./css/custom.css">
    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">
    <!-- font awsome cdn -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">

    <script src='../www.google.com/recaptcha/api.js'></script>
	<style>
.inner-banner{
		
		padding:43px;
		padding-top:80px;
		padding-bottom:90px;
		background-image:url('img/b1.jpg');
		-webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
	}
	#main{margin-top:130px;}
	.call-div{display:none}
	.text-center {
    text-align: center;
}
.box{background-color:red;}
.inner-banner .box {
    display: inline-block;
    border: 3px solid #fff;
    padding: 11px 47px;
}
	
	.inner-banner h3 {
    margin: 0;
    font-size: 40px;
    line-height: 42px;
    color: #fff;
    font-weight: 700;
}



@media (max-width:800px){
.inner-banner h3 {
    font-size: 25px;
}
.inner-banner {
padding-top:40px;
	padding-bottom:40px;
	padding:30px; 
}

#main{margin-top:80px;}
		
.call-div{display:block !important; bottom:0px; position:fixed; width:100%; z-index:1000; bottom:0; background:white; text-align:center; padding:10px; color:Black;}
.call-div a{color:#90b777;}

.contactspp{
		display:none;
}
.whatspp{
		display: block;
		position: fixed;
		bottom: 15%;
		left: 0%;
		height: 70px;
		height: 70px;
		width: 70px;
		left: auto;
		 z-index:111;
}
.whatspp img{
	height: 50px;
	width: 50px;
}

}



 </style>
</head>
<?php include("part/header.php"); ?>
<!-- #header -->
	

    <main id="main">

	 <section  class="inner-banner text-center" style="background-image:url('img/web-design.jpg')" >
            <div class="container">
                <div class="box">
                    <h3 id="headtop">
                    CREATIVE BRANDING</h3>
                </div>
            </div>
<body>
    <!--==========================
  Header
  ============================-->

    </header><!-- #header -->
    <!--Talk to an expert-->
    







    <!--==========================
    Intro Section
  ============================-->
    

        <!--==========================
      Technologies Section
    ============================-->
        <div class="container">
            <div class="owl-carousel clients-carousel">
                <img src="img/logos/angular.png" style="width:150px;padding:20px" alt="">
                <img src="img/logos/html1.png" style="width:150px;padding:20px" alt="">
                <img src="img/logos/ios.png" style="width:80px;padding:1px 0px;" alt="">
                <img src="img/logos/android.png" style="width:80px;padding:1px 0px" alt="">
                <img src="img/logos/php.png" style="width:100px;padding:10px" alt="">
                <img src="img/logos/css.png" style="width:80px;padding:10px" alt="">
                <img src="img/logos/laravel.png" style="width:160px;padding:20px" alt="">
            </div>
        </div>
    </section>

    <main id="main">

        <!--==========================
      About Us Section
    ============================-->

                   

        </section><!-- #about -->

        <!--==========================
      Features Section
    ==




      Services Section
    ============================-->
        <section id="services" class="section-bg">
            <div class="container">

                <header class="section-header">
                    <h3>    CREATIVE BRANDING</h3>
                    <p style="line-height: 2;" class="web"> At Presently digital solutions, we use the latest tools, hardware and software support in order to provide the best branding solutions and logo designing service to our customers. We also offer customer support if required.

Advancing business and promoting are the important apparatuses in order to take business to places and produce income. identity of your brand have an imperative role in determining the growth of your business. Presently Creative Branding Agency in Bhopal,indore is the renowned name in offering logo design and branding administrations. The organization takes a shot at the sole goal of consumer loyalty, in this manner we provide our clients with the best solutions according to their needs and demands..</p>

                        <!-- <a href="contact.php#contact"> -->
                        <a href="#footer"></a> 
                    </p>
                </header>

                <div class="row">

					<div class="col-md-6 col-lg-6 wow bounceInUp" data-wow-delay="0.1s" data-wow-duration="1.4s">
                        <div class="box">
                            <!-- <div class="icon" style="background: #e6fdfc;"><i class="ion-ios-paper-outline"
                  style="color: #3fcdc7;"></i></div> -->
                            <div class="icon" style="background: #fff0da;"><i class="
                        ion-ios-browsers" style="color: #413e66;"></i></div>

                            <h4 class="title"><a href="#"> LOGO CREATION</a></h4>
                            <p class="description" style="text-align: justify">To the general public, logos serve as an instant reminder of a company or a product; to the client they're the point of recognition on which their branding hangs; and to us designers they represent the challenge of incorporating our clients' ideologies into one single graphic. No wonder, then, that logo design features so prominently in our lives.</p>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-6 wow bounceInUp" data-wow-duration="1.4s">
                        <div class="box">
                            <div class="icon" style="background: #fff0da;"><i class="ion-ios-browsers-outline"
                                    style="color: #413e66;"></i></div>

                            <h4 class="title"><a href="#">NAMING & TITLING</a></h4>
                            <p class="description" style="text-align: justify">Each name offers its own particular one of a kind advantages, which is critical with the goal that your business name emerges. A business is regularly just fruitful once its name is effective. A paramount, brandable business name is the way to building a prominent brand.

    </p>
                            <br />
                            <br />
                            <!-- <br />
              <br />
              <br />
              <br /> -->
                        </div>
                    </div>
					
					  <div class="col-md-6 col-lg-6 wow bounceInUp" data-wow-delay="0.1s" data-wow-duration="1.4s">
                        <div class="box">
                            <div class="icon" style="background: #fff0da;"><i class="ion-ios-speedometer-outline"
                                    style="color:#413e66;"></i></div>
                            <h4 class="title"><a href="#">BRAND BOOK</a></h4>
                            <p class="description" style="text-align: justify">
                            A brand book or brand guidelines is essentially a set of rules that explain about your brand and describes how your brand works. Brand book includes informations like overview,history, vision, personality and key values of your brand, Specifications for logo setup.


                            </p>

                        </div>
                    </div>
					
					 <div class="col-md-6 col-lg-6 wow bounceInUp" data-wow-duration="1.4s">
                        <div class="box">
                            <div class="icon" style="background: #fff0da;"><i class="ion-ios-browsers-outline"
                                    style="color: #413e66;"></i></div>

                            <h4 class="title"><a href="#">BROCHURES & FLYERS
</a></h4>
                            <p class="description" style="text-align: justify">Flyers are single and unfolded sheet and it may be printed on one side or both sides. Flyers may be used for a variety of needs and they are normally used to convey short and concise messages. They are mainly used for shorter lifespan needs compared to most of the other print formats and they are easy to distribute. Flyers are also known as leaflets, circulars and handbills. Brochures are always folded sheets and they usually tend to be printed on both sides of the sheets. Brochures usually coming in a wide variety of folds. When compared to Flyers Distribution for brochures are comparatively more difficult because of the costs for printing.

</p>
                            <br />
                            <br />
                            <!-- <br />
              <br />
              <br />
              <br /> -->
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 wow bounceInUp    " data-wow-duration="1.4s">
                        <div class="box mobile " >
                            <div class="icon" style="background: #fff0da;">
                                <!-- <i class="ion-ios-bookmarks-outline" style="color: #e98e06;"></i> -->
                                <i class="ion-android-phone-portrait" style="color: #413e66;"></i>

                            </div>
                            <h4 class="title "><a href="#">COPY & CONTENT WRITING
</a></h4>
                            <p class="description" style="text-align: justify">Unlike traditional application softwares, Progressive Web Applications can be seen as an evolving hybrid of regular websites and mobile apps. This new application model combines features offered by most web browsers with the benefits of mobile user experience. Presently <a href="https://www.nellaiseo.com/website/web/design/company/in/tirunelveli.html">web designing company</a> helps our customers to build progressive web apps..</p>
                           
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 wow bounceInUp    " data-wow-duration="1.4s">
                        <div class="box mobile " >
                            <div class="icon" style="background: #fff0da;">
                             
                                <i class="fas fa-cloud-upload-alt" style="color: #413e66;"></i>

                            </div>
                            <h4 class="title "><a href="#">CORPORATE WEBSITE DEVELOPMENT</a></h4>
                            <p class="description" style="text-align: justify">Copywriting is contents written and conveyed through print materials and online media. Copywrite content is normally used for advertising or marketing needs. This type of copy content is always used to increase brand awareness. Content is the experience and data directed toward an end-user or audience. There many mediums that are normally used to convey content like writing, speech etc.






                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Modal ui/ux developement -->
        <div class="modal fade" id="myModalU" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">UI/UX DEVELOPMENT</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body scroll">
                        <p>&nbsp;&nbsp;&nbsp;We make things look pretty and ensure it meets all the necessary
                            micro-interactions
                            with our extensive
                            experience in wire-framing and business logic design for intuitive and useful products!</p>
                        <hr>
                        <p class="sub_heading">Our UX/UI Design Services Include:</p>
                        <ul class="sub_points">
                            <li>Interaction Design</li>
                            <li>Wire frames & Prototypes</li>
                            <li>Information Architecture</li>
                            <li>User Research & Usability Testing</li>
                            <li>Visual, Color and Graphic Design</li>
                            <li>Branding, Layouts & Typography</li>
                            <li>User Guides</li>
                        </ul>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal iOS -->
        <div class="modal fade" id="myModalI" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">

                        <h4 class="modal-title">IOS DEVELOPMENT</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>&nbsp;&nbsp;&nbsp;Apple apps offer some of the best user-experience and interface for a
                            variety of user
                            needs. Whether
                            it is for enterprise or consumer use, we can help design, develop and get iOS applications
                            approved in the
                            app store.</p>
                        <hr>
                        <p class="sub_heading">Our iOS Services Include:</p>
                        <ul class="sub_points">
                            <li>Mobile Prototyping</li>
                            <li>Front-End Storyboarding</li>
                            <li>Objective-C and Swift Programming</li>
                            <li>Field Service Apps</li>
                            <li>Enterprise & Business productivity</li>
                            <li>Gaming, Entertainment, Music & Media</li>
                            <li>GPS Based / Augmented Reality Apps</li>
                            <li>Subscription based</li>
                            <li>Custom Web Services & APIs</li>
                        </ul>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- #services -->
        <!--==========================
      Why Us Section
    ============================-->                                      

    <!--==========================
    Footer
  ============================-->
  <?php include("part/footer.php"); ?>
  <!-- #footer -->

</body>


</html>