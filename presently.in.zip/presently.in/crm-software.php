<!DOCTYPE html>
<html lang="en">


<head>
    <title>CRM SOFTWARE | Presently Solutions | Software Development Company</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
        content="At Presently, we make BRANDS AND BUSINESSES achieve exponential success by effectively leveraging the combined power of Mobile, Social Media, Web, Videos and Data Analytics to excite and engage consumers.
		"
        property="description">
    <meta name="author" content="Presently Solutions" property="author">
    <meta name="canonical" content="https://presently.in/crm-software.php	" property="canonical">
    <meta name="robots" content="Index, follow">
    <meta name="og:title" content="Presently Solutions:Top IT Company " property="og:title">
    <meta name="og:description" content="Presently Solutions software development company in Bhopal,India"
        property="og:description">
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <meta name="keywords" content="Leading It company in Bhopal,Customized software service,Web design and development,
         mobile app development, Software solutions,app developers, web application and development, leading software solution provider in Bhopal,India,Dynamic Websites,Bhopal web development, Bhopal mobile app development, Bhopal app developer, Bhopal web design, Bhopal logo design,
         US based IT company in Thrissur,Custom developed websites,WebSite Hosting,software support and solutions in Bhopal,India,
         Professionals in software development, Best software company in Central India " property="keywords">
    <meta name="keyphrase"
        content="Best Software company in thrissur, Top IT company in Bhopal,software solutions,
                Website design and development company Bhopal,IOS and Andoird application development company Thrissur" />
    <meta name="topic" content="Software" />
    <meta name="subject" content="CRM SOFTWARE" />
    <meta name="classification" content="Software,Website development,Leading,Best,Top Company" />
    <meta name="rating" content="general">
    <meta name="audience" content="all" />
    <meta property="og:type" content="Software Company" />
    <meta property="og:url" content="https://www.facebook.com/presentlysolutions/" />
    <meta property="og:site_name" content="www.Presently.in" />
    <meta name="og:image" content="img/companyculture.png" />
    <meta name="og:email" content=" info@presently.in" />
    <meta name="og:phone_number" content="+919993357325" />
    <meta itemprop="name" content="Software Company, Bhopal" />
    <meta itemprop="description"
        content="Presently Soultions is the top web designing and web development in Bhopal who offers attractive website designs with creative web designers in Bhopal" />
    <meta name="og:image" content="img/companyculture.png" property="og:image">
    <link rel="canonical" href="index.php" />
    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700"
        rel="stylesheet">
    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">

    <script src='../www.google.com/recaptcha/api.js'></script>

</head>

<body>
    <!--==========================
  Header
  ============================-->
<?php include("part/header.php"); ?>
<!-- #header -->
	

    <main id="main">

	 <section  class="inner-banner text-center" style="background-image:url('img/crm.jpg')">
            <div class="container">
                <div class="box">
                    <h3>
                    CRM </h3>
                </div>
            </div>
</section>

        <!--==========================
      About Us Section
    ============================-->
        <section id="about">

            <div class="container">
                <div class="row"> 

                    <div class="col-lg-12 col-md-12">
                        <div class="about-content">
                            <h2>CRM SOFTWARE</h2>
                            <p style="line-height: 2;">Canrone, a standout amongst other CRM programming for SME in India has every one of the abilities to satisfy your necessities of business upkeep. CRM is a compelling procedure to oversee and upgrade your organization's ties with existing and skilled clients in the market. Remembering about the genuine capability of a client in present days, Indglobal dependably centers around client maintenance and deals development. Our organization examinations your associations with clients and in like manner actualize CRM techniques to enhance your associations with them.</p>
							<p style="line-height: 2;">CRM programming offers a business the ability to allocate, This CRM programming make and oversee demand of the clients. It bring a kind of joint effort among the customers and representatives and there by expands the efficiency.</p>
<h4 style="font-weight: 800;">PRODUCT FEATURES</h4>
          <ul class="basic-listing">
            <li>Service Alerts</li>
                <li>Lead Management</li>
                <li>Sales Management</li>
                <li>Multi level Inventory</li>
                <li>Service Management</li>
                <li>Dispatch and Delivery</li>
                <li>Supplier Management</li>
                <li>Supply Chain Management</li>
                <li>User Access Security Management</li>
                <li>Inventory Management</li>
                <li>Purchase Management</li>
          </ul>
                        </div>
                        </div>
                        </div>
						
					
					
              
            </div>

        </section><!-- #about -->

       
     
  </main>
    <!--==========================
    Footer
  ============================-->
  <?php include("part/footer.php"); ?>
  <!-- #footer -->

    

</body>


</html>